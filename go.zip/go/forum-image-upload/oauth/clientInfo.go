package oauth

const (
	GoogleClientID     = ""
	GoogleClientSecret = ""
	GoogleRedirectURI  = "http://localhost:5000/oauth/google"
	GithubClientID     = ""
	GithubClientSecret = ""
	GithubRedirectURI  = "http://localhost:5000/oauth/github"
)
