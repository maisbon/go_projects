# FORUM PROJECT
Ce projet consiste à créer un forum web qui permet :

communication entre les utilisateurs.
associer des catégories aux publications.
aimer et ne pas aimer les publications et les commentaires.
filtrage des messages.
## Développeuses
Malarissa , Kstephanie, Kmakissi, Addosso, et Owingnagne.