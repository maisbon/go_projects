package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"strconv"
	"strings"
)

type Artist struct {
	Id           int                 `json:"id"`
	Image        string              `json:"image"`
	Name         string              `json:"name"`
	Members      []string            `json:"members"`
	CreationDate int                 `json:"creationDate"`
	FirstAlbum   string              `json:"firstAlbum"`
	Relations    map[string][]string `json:"relations"`
	Dates        []string            // Ajout du champ Dates
	Locations    []string            // Ajout du champ Locations
}

type Relations struct {
	Id        int                 `json:"id"`
	Relations map[string][]string `json:"datesLocations"`
}

type Filters struct {
	CreationDateStart int
	CreationDateEnd   int
	FirstAlbumStart   int
	FirstAlbumEnd     int
	NumMembers        int
	Locations         string
	Numbers_start     int
	Numbers_end       int
}

func createBody(link string) ([]byte, error) {
	var body []byte
	response, err := http.Get(link)
	if err != nil {
		fmt.Println("createBody error")
		return body, err
	}

	body, err = io.ReadAll(response.Body)
	if err != nil {
		fmt.Println("createBody error")
		return body, err
	}

	return body, nil
}

func getRelations() ([]Relations, error) {
	body, err := createBody("https://groupietrackers.herokuapp.com/api/relation")

	if err != nil {
		fmt.Println("getRelations error")
		return []Relations{}, err
	}

	var temp struct {
		Relations []Relations `json:"index"`
	}

	err = json.Unmarshal(body, &temp)
	if err != nil {
		fmt.Println("getRelations error")
		return []Relations{}, err
	}

	for i := range temp.Relations {
		relations := make(map[string][]string, 1)

		for key, dates := range temp.Relations[i].Relations {
			var modDates []string
			var modKey string

			modKey = strings.ReplaceAll(key, "-", ", ")
			modKey = strings.ReplaceAll(modKey, "_", " ")

			for _, date := range dates {
				modDates = append(modDates, strings.ReplaceAll(date, "-", "."))
			}

			relations[modKey] = modDates
			temp.Relations[i].Relations = relations
		}
	}

	return temp.Relations, nil
}

func GetArtists(filters Filters) ([]Artist, error) {
	var artists []Artist

	// Récupérer les artistes
	body, err := createBody("https://groupietrackers.herokuapp.com/api/artists")
	if err != nil {
		fmt.Println("GetArtist error")
		return []Artist{}, err
	}

	var temp []struct {
		Id           int      `json:"id"`
		Image        string   `json:"image"`
		Name         string   `json:"name"`
		Members      []string `json:"members"`
		CreationDate int      `json:"creationDate"`
		FirstAlbum   string   `json:"firstAlbum"`
		Relations    string   `json:"relations"`
	}

	err = json.Unmarshal(body, &temp)
	if err != nil {
		fmt.Println("GetArtist error")
		return []Artist{}, err
	}

	// Récupérer les relations (dates et emplacements)
	relations, err := getRelations()
	if err != nil {
		fmt.Println("GetArtist error")
		return []Artist{}, err
	}

	// Pour chaque artiste
	for v := range temp {
		var dates []string
		var locations []string

		// Récupérer les dates et les emplacements à partir des relations

		// Extraire l'année du premier album
		year, err := extractYear(temp[v].FirstAlbum)
		if err != nil {
			fmt.Println("Error extracting year from first album:", err)
			continue
		} // Récupérer les dates et les emplacements à partir des relations
		for key, datesStr := range relations[v].Relations {
			// Ajouter toutes les dates de datesStr à la liste des dates
			dates = append(dates, datesStr...)

			// Ajouter la clé (l'emplacement) à la liste des emplacements
			locations = append(locations, key)
		}

		// Créer l'artiste avec les données récupérées
		value := Artist{
			temp[v].Id,
			temp[v].Image,
			temp[v].Name,
			temp[v].Members,
			temp[v].CreationDate,
			strconv.Itoa(year), // Convertir l'année en string
			relations[v].Relations,
			dates,
			locations,
		}

		// Appliquer les filtres
		if passFilters(value, filters) {
			// Ajouter l'artiste à la liste
			artists = append(artists, value)
		}
	}

	return artists, nil
}
func passFilters(artist Artist, filters Filters) bool {
	// Vérifier chaque filtre
	if filters.CreationDateStart != 0 && artist.CreationDate < filters.CreationDateStart {
		return false
	}
	if filters.CreationDateEnd != 0 && artist.CreationDate > filters.CreationDateEnd {
		return false
	}
	if filters.FirstAlbumStart != 0 {

		albumYear, err := strconv.Atoi(artist.FirstAlbum)
		if err != nil {
			// Handle error converting album year to integer
			fmt.Println("Error converting album year to integer:", err)
			return false
		}
		if albumYear < filters.FirstAlbumStart {
			return false
		}
	}

	if filters.FirstAlbumEnd != 0 {

		albumYear, err := strconv.Atoi(artist.FirstAlbum)
		if err != nil {
			// Handle error converting album year to integer
			fmt.Println("Error converting album year to integer:", err)
			return false
		}
		if albumYear > filters.FirstAlbumEnd {
			return false
		}
	}
	if filters.Numbers_start != 0 {

		if len(artist.Members) < filters.Numbers_start {
			return false
		}
	}
	if filters.Numbers_end != 0 {

		if len(artist.Members) > filters.Numbers_end {
			return false
		}
	}

	if filters.NumMembers != 0 && len(artist.Members) != filters.NumMembers {
		return false
	}
	if filters.Locations != "" && !contains(artist.Locations, filters.Locations) {
		return false
	}

	return true
}

// Fonction utilitaire pour vérifier si une chaîne se trouve dans une liste de chaînes
func contains(locations []string, target string) bool {
	for _, loc := range locations {
		if loc == target {
			return true
		}
	}
	return false
}
func extractYear(dateString string) (int, error) {
	// Diviser la chaîne en tranches utilisant le séparateur "-"
	parts := strings.Split(dateString, "-")
	if len(parts) != 3 {
		return 0, fmt.Errorf("invalid date format: %s", dateString)
	}

	// Extraire l'année (la troisième partie)
	year, err := strconv.Atoi(parts[2])
	if err != nil {
		return 0, fmt.Errorf("failed to extract year: %v", err)
	}

	return year, nil
}

func Index(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		if r.URL.Path != "/" {
			t, _ := template.ParseFiles("templates/error.html")
			t.Execute(w, http.StatusNotFound)
			return
		}
		t, err := template.ParseFiles("templates/index.html")
		if err != nil {
			http.Error(w, "500: internal server error", http.StatusInternalServerError)
			return
		}

		// Extraire les valeurs des filtres de la requête
		filters := extractFiltersFromRequest(r)

		artist, err := GetArtists(filters)
		if err != nil {
			http.Error(w, "500: internal server error", http.StatusInternalServerError)
			return
		}
		t.Execute(w, artist)
	} else {
		http.Error(w, "404: Bad Request", http.StatusBadRequest)
		return
	}
}

func HandleArtist(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		t, err := template.ParseFiles("templates/profile.html")
		if err != nil {
			http.Error(w, "500: internal server error", http.StatusInternalServerError)
			return
		}
		artist, err := GetArtists(Filters{}) // No filters for individual artist view
		if err != nil {
			http.Error(w, "500: internal server error", http.StatusInternalServerError)
			return
		}
		urlString := string(r.URL.Path)[8:]
		for i, v := range artist {
			if v.Name == urlString {
				t.Execute(w, struct {
					Artist
					Dates     []string
					Locations []string
				}{
					Artist:    artist[i],
					Dates:     artist[i].Dates,
					Locations: artist[i].Locations,
				})

				return
			}
		}
		t, _ = template.ParseFiles("templates/error.html")
		t.Execute(w, http.StatusNotFound)
		return
	} else {
		http.Error(w, "404: bad request.", http.StatusBadRequest)
	}
}

func extractFiltersFromRequest(r *http.Request) Filters {
	var filters Filters

	// Extraire les valeurs des filtres de la requête
	query := r.URL.Query()

	if creationDateStart, err := strconv.Atoi(query.Get("creation_date_start")); err == nil {
		filters.CreationDateStart = creationDateStart
	}
	if creationDateEnd, err := strconv.Atoi(query.Get("creation_date_end")); err == nil {
		filters.CreationDateEnd = creationDateEnd
	}
	if num_members, err := strconv.Atoi(query.Get("num_members")); err == nil {
		filters.NumMembers = num_members
	}
	if first_album_start, err := strconv.Atoi(query.Get("first_album_start")); err == nil {
		filters.FirstAlbumStart = first_album_start
	}
	if first_album_end, err := strconv.Atoi(query.Get("first_album_end")); err == nil {
		filters.FirstAlbumEnd = first_album_end
	}

	if numbers_start, err := strconv.Atoi(query.Get("numbers_start")); err == nil {
		filters.Numbers_start = numbers_start
	}
	if numbers_end, err := strconv.Atoi(query.Get("numbers_end")); err == nil {
		filters.Numbers_end = numbers_end
	}
	filters.Locations = convertLocation(query.Get("locations"))

	// Extraire d'autres valeurs de filtre de la requête et les attribuer à filters
	return filters
}
func convertLocation(location string) string {
	// Remplacer les espaces et les virgules par des tirets et convertir en minuscules
	converted := strings.ToLower(location)

	return converted
}

func main() {
	http.Handle("/templates/", http.StripPrefix("/templates/", http.FileServer(http.Dir("./templates/"))))
	http.Handle("/css/", http.StripPrefix("/css/", http.FileServer(http.Dir("./css/"))))
	http.Handle("/images/", http.StripPrefix("/images/", http.FileServer(http.Dir("./images/"))))
	http.HandleFunc("/", Index)
	http.HandleFunc("/artist/", HandleArtist)
	fmt.Println("Server listening on port http://localhost:2072")
	http.ListenAndServe(":2072", nil)
}
