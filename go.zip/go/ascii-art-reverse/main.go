package main

import (
	"fmt"
	"os"
	"strings"
)

func main() {
	ok, er := vérifierArgs() // la fonction vérifie la validité des arguments
	
	if ok == true {          // si nous obtenons true de vérifierArgs, le travail commence =)

		// lecture du fichier ASCII-art

		fContenu, err := os.ReadFile("standard.txt")
		check(err)
		policeData := string(fContenu)
		police := strings.Split(policeData, "\n")

		// lecture du fichier art pour le renversement
		fichierTexte := os.Args[1][10:]
		textContenu, err := os.ReadFile(fichierTexte)
		check(err)
		textData := string(textContenu)
		texte := strings.Split(textData, "\n")

		// Si le fichier contient plus d'un objet ascii-art
		if len(texte) > 9 {
			for i := 0; i < len(texte)-1; {
				if len(texte[i]) > 0 {
					inverser(police, texte[i:i+8], 0, 0, 1)
					fmt.Println()
					i = i + 8
				} else {
					fmt.Println()
					i = i + 1
				}
			}
		} else {
			inverser(police, texte, 0, 0, 1)
			fmt.Println()
		}
	} else {
		fmt.Print(er)
	}

}

// pos - symbole dans le fichier ASCII-art (input.txt). Count - nombre de lignes dans le fichier ASCII-art (input.txt). Start - numéro de ligne dans le fichier de police (standard.txt)
func inverser(police []string, texte []string, pos int, compteur int, debut int) {
	if pos != len(texte[compteur]) { // si nous n'avons pas fini le renversement.
		l := len(police[debut]) // longueur du candidat pour la recherche
		if pos+l <= len(texte[compteur]) {
			if compteur < 7 {
				if texte[compteur][pos:l+pos] == police[debut+compteur] { // si la ligne de police et la ligne de l'ASCII-art sont égales
					inverser(police, texte, pos, compteur+1, debut) // compare la ligne suivante
				} else {
					inverser(police, texte, pos, 0, debut+9) // si elles ne sont pas égales, nous essayons le prochain symbole dans le fichier de police
				}
			} else {
				r := ((debut - 1) / 9) + 32 // trouve et imprime la lettre
				fmt.Printf("%c", r)
				inverser(police, texte, pos+l, 0, 1) // nous recommençons nos comptes pour la prochaine recherche
			}
		} else {
			inverser(police, texte, pos, 0, debut+9)
		}
	}
}
func check(e error) {
	if e != nil {
		panic(e)
	}
}

// l'argument doit commencer par --reverse=
func vérifierArgs() (bool, string) {
	ok := true
	s := ""
	if len(os.Args) != 2 || len(os.Args[1]) < 9 || os.Args[1][0:10] != "--reverse=" {
		ok = false
		s = "Usage: go run . [OPTION]\n\nEX: go run main.go --reverse=<fileName>\n"
	}
	return ok, s
}

