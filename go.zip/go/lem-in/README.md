# lem-in

Lem-In est un projet qui consiste à trouver le chemin le plus rapide pour déplacer un certain nombre de fourmis à travers une colonie composée de pièces et de tunnels. L'objectif est d'amener les fourmis de la pièce de départ à la pièce de fin avec le moins de mouvements possible. Le projet est implémenté en Go et suit des formats d'entrée et de sortie spécifiques.

## Structure du Projet

- **main.go:** Contient la logique principale du programme, y compris la lecture de l'entrée, le traitement des données, la recherche de chemins et l'affichage des résultats.
 
- **README.md:** Ce fichier, fournissant une vue d'ensemble du projet.

## Utilisation

Pour exécuter le programme, utilisez la commande suivante :

```bash
go run . <fichier_entree>
Exemple : go run example01.txt
```

- `<fichier_entree>` est le chemin vers un fichier décrivant les fourmis, les pièces et les tunnels.

## Format d'Entrée

Le fichier d'entrée doit contenir des informations sur les fourmis, les pièces et les tunnels. Le format inclut le nombre de fourmis, les détails des pièces (nom, coordonnées), les connexions des tunnels, et les déclarations de pièces de début/fin.

Exemple d'Entrée :

```plaintext
3
##start
1 23 3
2 16 7
3 16 3
##end
0 9 5
0-4
0-6
1-3
4-3
5-2
3-5
4-2
2-1
7-6
7-2
7-4
6-5
```

## Format de Sortie

Le programme affiche l'entrée d'origine et chaque mouvement des fourmis de pièce en pièce. La sortie inclut le nombre de fourmis et les déplacements de chaque fourmi.

Exemple de Sortie :

```plaintext
3
##start
1 23 3
2 16 7
3 16 3
##end
0 9 5
0-4
0-6
1-3
4-3
5-2
3-5
4-2
2-1
7-6
7-2
7-4
6-5

L1-3 L2-2
L1-4 L2-5 L3-3
L1-0 L2-6 L3-4
L2-0 L3-0
```

## Bonus: Visualiseur de Colonie de Fourmis

En bonus, vous pouvez créer un visualiseur de colonie de fourmis qui montre les fourmis se déplaçant à travers la colonie. Pour utiliser le visualiseur :

```bash
go run . <fichier_entree> | ./visualizer
```

Le visualiseur utilise les coordonnées des pièces pour l'affichage.

## Objectifs d'Apprentissage du Projet

- Résolution de problèmes algorithmiques.
- Manipulation des entrées et sorties en Go.
- Manipulation de chaînes et de structures.
- Tests unitaires avec des fichiers de test.
- Bonnes pratiques de codage et de style.

## Restrictions du Projet

- Utilisez uniquement les packages Go standard.
- Suivez de bonnes pratiques de codage.
- Implémentez des tests unitaires avec des fichiers de test.

## Remerciements

Ce projet fait partie du programme d'études à Digifemmes Academy. Un grand merci aux instructeurs et mentors pour leur guidance et leur soutien.