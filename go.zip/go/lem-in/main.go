package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
)

//la structure pour les pièces
type room struct {
	name     string
	colonne   int
	row      int
	nextRoom []*room
	start    bool
	end      bool
	visited  int
	nbFourmi int
}

type Fourmi struct {
	name     string
	room     *room
	prevRoom *room
	Chemin     string
}

var Fourmis []*Fourmi

//Recuperer le nombre de fourmis dans le fichier text qui va etre passé en argument
func chopFourmi() {
	data, err1 := os.Open(os.Args[1])
	if err1 != nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("File Error")
		log.Fatal()
	}
	chopfourmi := bufio.NewScanner(data)
	line := 0

	for chopfourmi.Scan() {
		if chopfourmi.Text() == "" {
			fmt.Println("ERROR: invalid data format")
			log.Fatal()
		}
		line++
		if line == 1 {
			a, err2 := strconv.Atoi(chopfourmi.Text())
			if a == 0 {
				fmt.Println("ERROR: invalid data format")
				
				log.Fatal()
			}
			if err2 != nil {
				fmt.Println("ERROR: invalid data format")
				fmt.Println("No ants found")
				log.Fatal()
			}
			Fourmis = make([]*Fourmi, a)
			for i := 0; i < a; i++ {
				FourmiName := &Fourmi{name: strconv.Itoa(i + 1)}
				Fourmis[i] = FourmiName
			}
		}
	}
}

var roomList []*room

// recuperer les piece qui sont des nombre suivi de 2 autres nombres qui sont les adresses de la pièce
func chopPlace() {
	data, err1 := os.Open(os.Args[1])
	if err1 != nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("File Error")
		log.Fatal()
	}

	var chaineVide string
	var getCoOrd string
	line := 0
	getCoOrds := bufio.NewScanner(data) //crée un scanner pour lire des données à partir du fichier rentree en argument
	for getCoOrds.Scan() {
		line++
		if line > 1 {
			if strings.Contains(getCoOrds.Text(), "#") {
				chaineVide = ""
			} else if strings.Contains(getCoOrds.Text(), "-") {
				chaineVide = ""
			} else {
				chaineVide = getCoOrds.Text() + "\n"
				getCoOrd += chaineVide
				chaineVide = ""
			}
		}
	}
	var a []string
	var rooms *room
	var rowInt int
	var colonneInt int

	// ici on ajoute des coordonnées à leur structure de pièce respective les cordonnées sont les 2 lettres qui suivent le nom de la pièce
	for i := 0; i < len(getCoOrd); i++ {
		if getCoOrd[i] != 10 {
			chaineVide += string(getCoOrd[i])
		}
		if getCoOrd[i] == 10 {
			a = strings.Split(chaineVide, " ")
			colonneInt, _ = strconv.Atoi(a[1])
			rowInt, _ = strconv.Atoi(a[2])
			rooms = &room{name: a[0]}
			rooms.colonne = colonneInt
			rooms.row = rowInt
			roomList = append(roomList, rooms)
			chaineVide = ""
		}
	}
}

// ici on cherche les liens entre 2 pièces dans le fichier qu'on mets dans un tableau les liens entre 2 pièces sont deux nombres separées par des tirets
func liaison() {
	data, err1 := os.Open(os.Args[1])
	if err1 != nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("File Error")
		log.Fatal()
	}
	var chaineVide string
	var links []string
	line := 0
	linksInfo := bufio.NewScanner(data)
	for linksInfo.Scan() {
		line++
		if line > 1 {
			if strings.Contains(linksInfo.Text(), "-") {
				chaineVide = linksInfo.Text()
				links = append(links, chaineVide)
			} else {
				chaineVide = ""
			}
		}
	}

	for i := range links {
		for j := range links[i] {
			if links[i][j] == '-' {
				linkString := strings.Split(links[i], "-")
				for k := range roomList {
					for o := range roomList {
						if linkString[0] == roomList[k].name && roomList[o].name == linkString[1] {
							roomList[k].nextRoom = append(roomList[k].nextRoom, roomList[o])
						} else if linkString[1] == roomList[k].name && roomList[o].name == linkString[0] {
							roomList[k].nextRoom = append(roomList[k].nextRoom, roomList[o])
						}
					}
				}
			}
		}
	}
}

// ici on cherche la pièce de commencement c'est la suite de nombre qui suit le mot ##start
var (
	Start    *room
	lenStart int
)

func assignStart() {
	data, err1 := os.Open(os.Args[1])
	if err1 != nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("File Error")
		log.Fatal()
	}
	var getStart []string
	var startLine string

	startInfo := bufio.NewScanner(data)
	for startInfo.Scan() {
		getStart = append(getStart, startInfo.Text())
	}

	for i := range getStart {
		if getStart[i] == "##start" {
			startLine = getStart[i+1]
		}
	}
	a := strings.Split(startLine, " ")
	for _, ele := range roomList {
		if ele.name == a[0] {
			ele.start = true
		}
	}
	for i := range roomList {
		if roomList[i].start {
			Start = roomList[i]
		}
	}
	if Start == nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("No Start Room Found")
		log.Fatal()
	}
	lenStart = len(Start.nextRoom)
	if lenStart == 0 {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("No rooms connecting to Start")
		log.Fatal()
	}
	roomChemins = make([]string, 5)
}

// ici on cherche la pièce de fin c'est la suite de nombre qui suit le mot ##end
var End *room

func assignEnd() {
	data, err1 := os.Open(os.Args[1])
	if err1 != nil {
		fmt.Println("ERROR: invalid data format")
		fmt.Println("File Error")
		log.Fatal()
	}
	var getEnd []string
	var endLine string

	endInfo := bufio.NewScanner(data)
	for endInfo.Scan() {
		getEnd = append(getEnd, endInfo.Text())
	}

	for i := range getEnd {
		if getEnd[i] == "##end" {
			endLine = getEnd[i+1]
		}
	}
	a := strings.Split(endLine, " ")
	for _, ele := range roomList {
		if ele.name == a[0] {
			ele.end = true
			End = ele
		}
	}
	if End == nil {
		fmt.Println("ERROR: invalid data format")
		//fmt.Println("No End Room assigned")
		log.Fatal()
	}
	if End.nextRoom == nil {
		fmt.Println("ERROR: invalid data format")
		log.Fatal()
	}
	End.nbFourmi = len(Fourmis)
}

// ici on va trouver le chemin entre le debut et la fin en parcourant les pièces
var (
	count     int
	roomChemins []string
)

func touChemins(r *room) {
	prevRoom := r
	nextRoom := r.nextRoom
	visitedCounter := 0
	lenCounter := 0
	if prevRoom.end {
		roomChemins[count] += prevRoom.name
		roomChemins[count] = startEnd(roomChemins[count])
		Start.visited = 0
		End.visited = 0
		count++
		touChemins(Start)
	}
	for _, ele := range nextRoom {
		if ele.visited == 1 {
			visitedCounter++
		}
	}

	if visitedCounter == len(nextRoom) {
		prevRoom.visited = 1
		dEndNameSlice := strings.Split(roomChemins[count], ",")
		for _, room := range roomList {
			if len(dEndNameSlice) >= 2 {
				if dEndNameSlice[len(dEndNameSlice)-2] == room.name {
					dEndNameSlice = remove(dEndNameSlice, len(dEndNameSlice)-2)
					roomChemins[count] = strings.Join(dEndNameSlice, ",")
				}
			}
		}
	} else {
		for _, roomele := range nextRoom {
			lenCounter++
			if prevRoom == Start {
				for i, rooms := range nextRoom {
					if count < lenStart {
						rNamesSlice := strings.Split(roomChemins[count], ",")
						if !contains(rNamesSlice, rooms.name) && (rooms.visited == 0) && !strings.HasPrefix(rooms.name, "G") {
							roomChemins[count] += prevRoom.name + ","
							prevRoom.visited = 1
							touChemins(nextRoom[i])
						}
					}
				}
			}
			if roomele.end {
				if count < lenStart {
					roomChemins[count] += prevRoom.name + ","
					prevRoom.visited = 1
					touChemins(roomele)
				}
			} else if lenCounter == len(nextRoom) {
				for _, check := range nextRoom {
					for _, endNextRooms := range End.nextRoom {
						if check.name == endNextRooms.name && check.visited == 0 {
							if count < lenStart {
								rNamesSlice := strings.Split(roomChemins[count], ",")
								if !contains(rNamesSlice, check.name) && !strings.HasPrefix(check.name, "G") {
									if prevRoom != End {
										check.visited = 1
										endNextRooms.visited = 1
										prevRoom.visited = 1
										roomChemins[count] += prevRoom.name + ","
										roomChemins[count] += check.name + ","
										touChemins(End)
									}
								}
							}
						}
					}
				}
				for i, rooms := range nextRoom {
					if count < lenStart {
						rNamesSlice := strings.Split(roomChemins[count], ",")
						if !contains(rNamesSlice, rooms.name) && (rooms.visited == 0) && !strings.HasPrefix(rooms.name, "G") {
							if prevRoom != End {
								roomChemins[count] += prevRoom.name + ","
								prevRoom.visited = 1
								touChemins(nextRoom[i])
							}
						}
					}
				}
			}
		}
	}
}

// on verrifie si la pièce contiient une fourmie
func contains(s []string, e string) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

// supprime une pièce
func remove(slice []string, s int) []string {
	return append(slice[:s], slice[s+1:]...)
}

//Supprimer les chemins invalides
func startEnd(s string) string {
	a := strings.Split(s, ",")
	if a[0] == Start.name && a[len(a)-1] == End.name {
	} else {
		s = ""
	}
	return s
}

// removes empty Chemins from Chemin's array
var finalChemin []string

func Final() {
	for i := range roomChemins {
		if roomChemins[i] != "" {
			finalChemin = append(finalChemin, roomChemins[i])
		}
	}

	for k := range roomList {
		if roomList[k].nextRoom != nil {
			roomList[k].visited = 0
			roomList[k].nextRoom = nil
		}
	}

	for i := range roomChemins {
		b := strings.Split(roomChemins[i], ",")
		for o := 0; o < len(b)-1; o++ {
			for k := range roomList {
				for l := range roomList {
					if b[o] == roomList[k].name && b[o+1] == roomList[l].name {
						roomList[k].nextRoom = append(roomList[k].nextRoom, roomList[l])
					}
				}
			}
		}
	}
}

// ici on trie les pièces par odre croissant
func Sort() {
	for i := 0; i < len(finalChemin)-1; i++ {
		if len(finalChemin[i]) > len(finalChemin[i+1]) {
			g := finalChemin[i]
			h := finalChemin[i+1]
			finalChemin[i] = h
			finalChemin[i+1] = g
		} else if len(finalChemin[i+1]) < len(finalChemin[i]) {
			g := finalChemin[i+1]
			h := finalChemin[i]
			finalChemin[i] = h
			finalChemin[i+1] = g
		}
	}
}

// retrouve le plus petit chemin et nous renvoie son indice
var roomLength []int

func minChemin(roomLength []int) int {
	min := roomLength[0]
	index := 0
	for i, room := range roomLength {
		if room < min {
			min = room
			index = i
		}
	}
	return index
}

//cette méthode attribue le chemin approprié à chaque fourmi avec le plus petit nombre de tours.
func assignChemins() {
	for i := range finalChemin {
		a := strings.Split(finalChemin[i], ",")
		roomLength = append(roomLength, (len(a) - 2))
	}
	for n := range Fourmis {
		Fourmis[n].Chemin = finalChemin[minChemin(roomLength)]
		roomLength[minChemin(roomLength)]++
		a := strings.Split(Fourmis[n].Chemin, ",")
		for _, ele := range Start.nextRoom {
			if ele.name == a[1] {
				Fourmis[n].room = ele
			}
		}
	}
}

//ici on fait passer une fourmie du debut jusqu'a la sortie en Renomant la fourmie de la lettre L suivie de son numero ensuite un tiret et le numéro de la pièce dans laquelle elle va

var FourmiChemin string

func TraverseChemin(r *room) {
	endFourmis := 0
	for endFourmis != End.nbFourmi {
		for i := range Fourmis {
			if i < len(Fourmis)-1 {
				if Fourmis[i].room.visited == 0 && !Fourmis[i].room.end {
					Fourmis[i].room.visited = 1
					FourmiChemin += string("L"+Fourmis[i].name+"-"+Fourmis[i].room.name) + " "
					Fourmis[i].prevRoom = Fourmis[i].room
					Fourmis[i].room = Fourmis[i].room.nextRoom[0]
				} else if Fourmis[i].room.visited == 0 && Fourmis[i].room.end {
					if !strings.Contains(FourmiChemin, string("L"+Fourmis[i].name)+"-"+Fourmis[i].room.name) {
						FourmiChemin += "L" + Fourmis[i].name + "-" + Fourmis[i].room.name + " "
						Fourmis[i].prevRoom = Fourmis[i].room
						endFourmis++
					}
				}
			} else if i == len(Fourmis)-1 {
				if Fourmis[i].room.end {
					FourmiChemin += string("L"+Fourmis[i].name+"-"+Fourmis[i].room.name) + " "
					endFourmis++
				}
				if Fourmis[i].room.visited == 0 && !Fourmis[i].room.end {
					Fourmis[i].room.visited = 1
					FourmiChemin += "L" + Fourmis[i].name + "-" + Fourmis[i].room.name + " "
					Fourmis[i].prevRoom = Fourmis[i].room
					Fourmis[i].room = Fourmis[i].room.nextRoom[0]
				}
				for j := range Fourmis {
					if Fourmis[j].prevRoom != nil {
						Fourmis[j].prevRoom.visited = 0
					}
				}
			}
		}

		FourmiChemin += "\n"
	}

	FourmiChemin = FourmiChemin[:len(FourmiChemin)-1]
}

func main() {
	chopFourmi()
	chopPlace()
	liaison()
	assignStart()
	assignEnd()
	touChemins(Start)
	Final()
	Sort()
	assignChemins()
	TraverseChemin(Start)
	file, _ := os.ReadFile(os.Args[1])
	fmt.Println(string(file) + "\n")
	fmt.Println(FourmiChemin)
}
