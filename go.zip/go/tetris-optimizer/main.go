package main

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"math"
	"os"
)

var game [][]string

func main() {
	args := os.Args[1]
	if args != "" {
		file, err := os.Open(args)
		if err != nil {
			fmt.Println(err.Error())
			os.Exit(0)
		}
		defer func() {
			if err = file.Close(); err != nil {
				fmt.Println(err)
				os.Exit(0)
			}
		}()
		var Array = Read(file) // appel la fonction pour lire le fichier
		Solve(Array)           // appel la fonction pour resolver le probrême
		PrintSol()             // appel la fonction pour imprimer la solution
	}
}
func Read(file io.Reader) [][4][4]string { // prend en entrée un lecteur (un fichier dans ce cas) et retourne un tableau de tétriminos.
	var tetriArray [][4][4]string
	var tetro [4][4]string
	scanner := bufio.NewScanner(file)
	i, in, flag, alpha := 0, 0, true, "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	for scanner.Scan() {
		str := scanner.Text()
		if str == "" {
			if flag {
				flag = false
				continue
			} else {
				fmt.Println("ERROR")
				os.Exit(0)
			}
		}
		var arr [4]string
		if len(str) != 4 {
			fmt.Println("ERROR")
			os.Exit(0)
		}
		for ind := range arr {
			if rune(str[ind]) == '.' {
				arr[ind] = "."
			} else if rune(str[ind]) == '#' {
				arr[ind] = string(alpha[in])
			} else {
				fmt.Println("ERROR")
				os.Exit(0)
			}
		}
		tetro[i] = arr
		i++
		if i == 4 {
			flag = true
			i = 0
			in++
			if !CheckTetromino(tetro) {
				fmt.Println("ERROR")
				os.Exit(0)
			}
			tetro = OptimizeTetri(tetro)
			tetriArray = append(tetriArray, tetro)
		}
	}
	if err := scanner.Err(); err != nil {
		log.Fatal(err)
		os.Exit(1)
	}
	return tetriArray
}
func OptimizeTetri(tetri [4][4]string) [4][4]string {
	i := 0
	for {
		zeroes := 0
		for j := 0; j < 4; j++ {
			if tetri[i][j] == "." {
				zeroes++
			}
		}
		if zeroes == 4 {
			tetri = ShiftVertical(tetri)
			continue
		}
		break
	}
	for {
		zeroes := 0
		for j := 0; j < 4; j++ {
			if tetri[j][i] == "." {
				zeroes++
			}
		}
		if zeroes == 4 {
			tetri = ShiftHorizontal(tetri)
			continue
		}
		break
	}
	return tetri
}
func ShiftVertical(tetromino [4][4]string) [4][4]string {
	temp := tetromino[0]
	tetromino[0] = tetromino[1]
	tetromino[1] = tetromino[2]
	tetromino[2] = tetromino[3]
	tetromino[3] = temp
	return tetromino
}
func ShiftHorizontal(tetromino [4][4]string) [4][4]string {
	tetromino = Transpose(tetromino)
	tetromino = ShiftVertical(tetromino)
	tetromino = Transpose(tetromino)
	return tetromino
}
func Transpose(slice [4][4]string) [4][4]string {
	xl := len(slice[0])
	yl := len(slice)
	var result [4][4]string
	for i := range result {
		result[i] = [4]string{}
	}
	for i := 0; i < xl; i++ {
		for j := 0; j < yl; j++ {
			result[i][j] = slice[j][i]
		}
	}
	return result
}
func CheckTetromino(tetromino [4][4]string) bool {
	c, d := 0, 0
	for a, elem := range tetromino {
		for b, elem2 := range elem {
			if elem2 != "." {
				d++
				if a+1 < 4 && tetromino[a+1][b] != "." {
					c++
				}
				if a-1 >= 0 && tetromino[a-1][b] != "." {
					c++
				}
				if b+1 < 4 && tetromino[a][b+1] != "." {
					c++
				}
				if b-1 >= 0 && tetromino[a][b-1] != "." {
					c++
				}
			}
		}
	}
	if d != 4 {
		return false
	}
	if c == 6 || c == 8 {
		return true
	}
	return false
}
func Solve(tetrominoes [][4][4]string) [][]string {
	l := int(math.Ceil(math.Sqrt(float64(4 * len(tetrominoes)))))
	game = InitSquare(l)
	for !BacktrackSolver(tetrominoes, 0) {
		l++
		game = InitSquare(l)
	}
	return game
}
func InitSquare(n int) [][]string {
	var Sqr [][]string
	var row []string
	for i := 0; i < n; i++ {
		for j := 0; j < n; j++ {
			row = append(row, ".")
		}
		Sqr = append(Sqr, row)
		row = []string{}
	}
	return Sqr
}
func BacktrackSolver(tetrominoes [][4][4]string, n int) bool {
	if n == len(tetrominoes) {
		return true
	}
	for i := 0; i < len(game); i++ {
		for j := 0; j < len(game); j++ {
			if CheckInsert(i, j, tetrominoes[n]) {
				Insert(i, j, tetrominoes[n])
				if BacktrackSolver(tetrominoes, n+1) {
					return true
				}
				Remove(i, j, tetrominoes[n])
			}
		}
	}
	return false
}
func CheckInsert(i, j int, tetro [4][4]string) bool {
	for a := 0; a < 4; a++ {
		for b := 0; b < 4; b++ {
			if tetro[a][b] != "." {
				if i+a == len(game) || j+b == len(game) || game[i+a][j+b] != "." {
					return false
				}
			}
		}
	}
	return true
}
func Insert(i, j int, tetro [4][4]string) {
	a, b, c := 0, 0, 0
	for a < 4 {
		for b < 4 {
			if tetro[a][b] != "." {
				c++
				game[i+a][j+b] = tetro[a][b]
				if c == 4 {
					break
				}
			}
			b++
		}
		b = 0
		a++
	}
}
func Remove(i, j int, tetro [4][4]string) {
	a, b, c := 0, 0, 0
	for a < 4 {
		for b < 4 {
			if tetro[a][b] != "." {
				if c == 4 {
					break
				}
				game[i+a][j+b] = "."
			}
			b++
		}
		b = 0
		a++
	}
}
func PrintSol() {
	for i := range game {
		for j := range game {
			fmt.Printf("%s  ", game[i][j])
		}
		fmt.Printf("\n")
	}
}
