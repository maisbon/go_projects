go run . hardexample.txt
go run . badexample00.txt
go run . badexample01.txt
go run . badexample02.txt
go run . badexample03.txt
go run . badexample04.txt
go run . badformat.txt

go run . goodexample01.txt
go run . goodexample02.txt
go run . goodexample03.txt

