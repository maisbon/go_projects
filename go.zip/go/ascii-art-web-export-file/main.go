package main

import (
	"fmt"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
)

type FormeData struct {
	Texte  string
	Format string
	Result string
	Lien   string
}

func getASCIIOfLetters(text string, alpha map[rune][]string) [][]string {
	var result [][]string
	for _, letter := range text {
		result = append(result, alpha[letter])
	}
	return result
}

func joinASCIIs(asciis [][]string, nbLines int) []string {
	var result []string
	for line := 0; line < nbLines; line++ {
		var res string

		for _, ascii := range asciis {
			if len(ascii) != 0 {
				res += ascii[line]
			}

		}
		result = append(result, res)

	}
	return result
}

func translate(text string, alpha map[rune][]string) []string {
	// Le pipeline de notre code. La fonction d'entrée qui sera appelée dans le main()
	// Il appelle chaque fonction dans l'ordre voulu pour atteindre le résultat
	// 'text' est le texte à afficher
	// 'alpha' est notre alphabet ascii (notre dictionnaire)
	asciis := getASCIIOfLetters(text, alpha) // obtenir le code ascii de chaque lettre du texte
	ascii_lines := joinASCIIs(asciis, 8)     // joindre les lignes des codes ascii ensembles
	//printASCII(ascii_lines)                  // afficher le résultat
	return ascii_lines
}

// bibliotheque
func getAlphabet(name string, nblines int) map[rune][]string {
	//asciiChars est un tableau qui contient touts les
	var asciiChars = []rune{' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E',
		'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[',
		'\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
		'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'}
	file := name + ".txt"
	alphabet := make(map[rune][]string)
	content, err := ioutil.ReadFile(file)
	if err != nil {
		fmt.Println("Erreur lors de la lecture du fichier :", err)

		return nil
	}
	//creer un tableau avec chaque lettre du fichier
	lines := strings.Split(string(content), "\n")
	//nombre de lignes du tableau et represente aussi le nombre de ligne dans le fichier standart
	nbTabLines := len(lines)
	var letter []string
	var nbAddition int
	for idx := 0; idx < nbTabLines; idx++ {
		if idx%nblines == 0 {
			if len(letter) != 0 {
				alphabet[asciiChars[nbAddition]] = letter
				// '!':[]
				// '#':[]
				letter = nil
				nbAddition++
			}
		} else {
			line := lines[idx]
			letter = append(letter, strings.Replace(line, "\\n", "", -1)[:len(line)-1])
		}
	}
	return alphabet
}

func main() {
	fmt.Println("Go app...")

	home := func(w http.ResponseWriter, r *http.Request) {

		if r.Method == "GET" && r.URL.Path == "/" {
			tmpl := template.Must(template.ParseFiles("Templates/index.html"))
			err := tmpl.Execute(w, tmpl)

			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
		} else {
			http.NotFound(w, r)

		}

	}
	result := func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "POST" && r.URL.Path == "/ascii-art" {
			title := r.PostFormValue("texte")
			director := r.PostFormValue("banner")
			if title == "" || director == "" {
				w.WriteHeader(http.StatusBadRequest)
			} else {

				fichier, errFile := os.Create("resources/result.txt")
				if errFile != nil {
					return
				}
				defer fichier.Close()

				lines := strings.Split(title, "\n")
				name := director
				nblines := 9
				// Crée un tableau et place chaque ligne dans une cellule

				nbr := len(lines)
				var tableau [10]string
				for i, line := range lines {
					if i < nbr { // Pour s'assurer que nous n'essayons pas d'accéder à une cellule inexistante
						tableau[i] = line
					}
				}
				var result []string
				alphabet := getAlphabet(name, nblines)
				for i := 0; i < len(tableau); i++ {

					resultat := translate(tableau[i], alphabet)
					result = append(result, strings.Join(resultat, "\n"))

				}

				resul := append(result, "\n")
				_, errFile = fichier.WriteString(strings.Join(resul, "\n"))
				if errFile != nil {
					return
				}
				tmpl := template.Must(template.ParseFiles("Templates/result.html"))
				err := tmpl.Execute(w, FormeData{Texte: title, Result: strings.Join(result, "\n")})
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
			}
		} else {
			w.WriteHeader(http.StatusBadRequest)
		}
	}

	downloadHandler := func(w http.ResponseWriter, r *http.Request) {
		// Chemin vers ton fichier
		cheminFichier := "resources/result.txt"
		nomFichier := "result.txt"

		// Ouvre le fichier
		fichier, err := os.Open(cheminFichier)
		if err != nil {
			http.Error(w, "Impossible d'ouvrir le fichier", http.StatusInternalServerError)
			return
		}
		defer fichier.Close()

		// Obtient les informations sur le fichier (y compris le temps de modification)
		info, err := fichier.Stat()
		if err != nil {
			http.Error(w, "Impossible d'obtenir les informations sur le fichier", http.StatusInternalServerError)
			return
		}

		// Configure les en-têtes pour le téléchargement
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Disposition", "attachment; filename="+nomFichier)
		w.Header().Set("Content-Length", fmt.Sprint(info.Size()))

		// Transmet le contenu du fichier au client
		http.ServeContent(w, r, nomFichier, info.ModTime(), fichier)
	}

	// define handlers
	// Définit le gestionnaire pour la route "/download"
	http.HandleFunc("/download", downloadHandler)
	http.HandleFunc("/", home)
	http.HandleFunc("/ascii-art", result)
	http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
	log.Fatal(http.ListenAndServe(":8000", nil))

}
