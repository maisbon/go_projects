## Dockerfile pour l'application [ asci-art-web ]
Ce Dockerfile est destiné à la construction d'une image Docker pour l'application [Nom de votre application]. Il utilise l'image de base golang:1.16-alpine pour créer un environnement léger avec Go.

## Instructions Dockerfile
1. Spécification de l'image de base
# FROM golang:1.16-alpine
Utilise l'image de base golang:1.16-alpine, qui est une image légère d'Alpine Linux avec Go installé.

2. Métadonnées
LABEL maintainer="Votre Nom <votre@email.com>" \
      version="1.0" \
      description="Une brève description de votre application."

3. Définition du répertoire de travail
# WORKDIR /app
Définit le répertoire de travail à l'intérieur du conteneur sur /app, où les commandes suivantes seront exécutées.

4. Copie des fichiers Go
# COPY go.mod .
# COPY go.sum .
Copie les fichiers go.mod et go.sum depuis le contexte de construction dans le répertoire de travail actuel du conteneur.

5. Téléchargement des modules Go
# RUN go mod download
Télécharge les modules et les dépendances Go définis dans go.mod.

6. Copie du code source
COPY . .
Copie le reste du code source de l'application et les fichiers depuis le contexte de construction dans le répertoire de travail actuel du conteneur.

7. Compilation du code source
RUN go build -o main .
Compile le code source pour créer l'exécutable main.

8. Exposition du port
EXPOSE 8000
informe Docker que le conteneur écoutera sur le port 8000 au moment de l'exécution.

9. Commande de démarrage
CMD ["./main"]
Spécifie la commande pour démarrer le service lors de l'exécution du conteneur.

## Exercution du projet
docker image build -f Dockerfile -t <name_de_limage> .
docker container run -p 8000:8000 --detach --name <name_of_the_container> <name_of_the_image>
docker exec -it postgres sh
Conteneurs : Docker utilise des conteneurs pour encapsuler des applications et leurs dépendances


Docker est une plateforme qui permet d'emballer une application et toutes ses dépendances dans un "conteneur". Un conteneur est un environnement léger et autonome qui peut être exécuté de manière cohérente sur n'importe quel système compatible avec Docker. Cela simplifie le déploiement des applications, garantit une portabilité élevée et facilite la gestion des ressources. En résumé, Docker simplifie le processus de distribution et d'exécution des applications.

Conteneurs : Docker utilise des conteneurs pour encapsuler des applications et leurs dépendances, permettant ainsi une exécution cohérente et prévisible sur divers environnements.

Images Docker : Une image Docker est un package léger, autonome et exécutable qui comprend tout le nécessaire pour exécuter une application, y compris le code, les dépendances, le système d'exploitation, les variables d'environnement, etc. Les images Docker servent de base pour créer des conteneurs.

Dockerfile : Un Dockerfile est un script texte qui contient des instructions pour construire une image Docker. Il spécifie les étapes nécessaires pour créer une image, y compris l'installation des dépendances, la configuration de l'environnement et la copie des fichiers nécessaires.



