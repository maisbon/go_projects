package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strconv"
)

// Structures pour stocker les données de l'API
type Artist struct {
	ID           int      `json:"id"`
	Image        string   `json:"image"`
	Name         string   `json:"name"`
	Members      []string `json:"members"`
	CreationDate int      `json:"creationDate"`
	FirstAlbum   string   `json:"firstAlbum"`
	Locations    string   `json:"locations"`
	Relations    string   `json:"relations"`
}

type Relation struct {
	ID             int                 `json:"id"`
	DatesLocations map[string][]string `json:"datesLocations"`
}

// Définir une structure pour stocker les URL de l'API
type Urls struct {
	Artists   string `json:"artists"`
	Locations string `json:"locations"`
	Dates     string `json:"dates"`
	Relation  string `json:"relation"`
}

type ArtistDetail struct {
	ID             int                 `json:"id"`
	Image          string              `json:"image"`
	Name           string              `json:"name"`
	Members        []string            `json:"members"`
	CreationDate   int                 `json:"creationDate"`
	FirstAlbum     string              `json:"firstAlbum"`
	Location       []string            `json:"location"`
	Dates          []string            `json:"dates"`
	DatesLocations map[string][]string `json:"datesLocations"`
	PointLocations []LocationPoint     `json:"pointLocations"`
}

type Location struct {
	//URL string `json:"locations"`
	ID        int      `json:"id"`
	Locations []string `json:"locations"`
}

type LocationPoint struct {
	Lat string `json:"lat"`
	Lon string `json:"lon"`
}

type Dates struct {
	ID    int      `json:"id"`
	Dates []string `json:"dates"`
}

// Fonctions pour manipuler les données de l'API
func getArtists() ([]Artist, error) {
	// Définir l'URL de l'API des artistes
	apiUrl := "https://groupietrackers.herokuapp.com/api/artists"

	// Effectuer la requête HTTP GET à l'API
	response, err := http.Get(apiUrl)
	if err != nil {
		return nil, err
	}

	//Cette ligne lit le corps de la réponse HTTP et stocke les données lues dans la variable
	bodyresponse, error := ioutil.ReadAll(response.Body)
	if error != nil {
		log.Fatalln(error)
	}

	// Décodez le corps JSON en une liste de structures Artist
	var artists []Artist
	err = json.Unmarshal(bodyresponse, &artists)
	if err != nil {
		return nil, err
	}

	return artists, nil
}

// Modifier la fonction getID pour retourner la structure Relation
func getID(id int) (*Artist, error) {
	// Définir l'URL de l'API pour récupérer les données d'un artiste par ID
	apiUrl := fmt.Sprintf("https://groupietrackers.herokuapp.com/api/artists/%d", id)
	//fmt.Println("api", apiUrl)
	// Effectuer la requête HTTP GET à l'API
	response, err := http.Get(apiUrl)
	if err != nil {
		return nil, err
	}
	//defer response.Body.Close()
	//fmt.Println("response----------------------", response.Body)

	// Vérifier si la réponse est 404 (Not Found)
	if response.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("artist not found with ID: %d", id)
	}
	bodyresponse, error := ioutil.ReadAll(response.Body)
	if error != nil {
		log.Fatalln(error)
	}

	// Décodez le corps JSON en une structure Relation

	var detailArtist Artist
	err = json.Unmarshal(bodyresponse, &detailArtist)
	if err != nil {
		return nil, err
	}

	return &detailArtist, nil
}

func getLocations(artistID int) (*Location, error) {
	apiUrl := fmt.Sprintf("https://groupietrackers.herokuapp.com/api/locations/%d", artistID)
	//fmt.Println("-------------la fonction location", artistID)
	response, err := http.Get(apiUrl)

	if err != nil {
		return nil, err
	}
	//defer response.Body.Close()
	//fmt.Println("response----------------------", response)
	// Vérifier si la réponse est 404 (Not Found)
	if response.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("artist not found with ID: %d", artistID)
	}
	body, error := ioutil.ReadAll(response.Body)
	if error != nil {
		log.Fatalln(error)
	}

	// Décodez le corps JSON en une structure Relation
	var locations Location
	err = json.Unmarshal(body, &locations)
	if err != nil {
		return nil, err
	}

	return &locations, nil
}

func getConcertDattes(artistID int) (*Dates, error) {
	apiUrl := fmt.Sprintf("https://groupietrackers.herokuapp.com/api/dates/%d", artistID)
	//fmt.Println("-------------la fonction date", artistID)
	response, err := http.Get(apiUrl)

	if err != nil {
		return nil, err
	}
	//defer response.Body.Close()
	//fmt.Println("response----------------------", response)

	// Vérifier si la réponse est 404 (Not Found)
	if response.StatusCode == http.StatusNotFound {
		return nil, fmt.Errorf("artist not found with ID: %d", artistID)
	}
	body, error := ioutil.ReadAll(response.Body)
	if error != nil {
		log.Fatalln(error)
	}
	// Décodez le corps JSON en une structure Relation
	var concertDates Dates
	err = json.Unmarshal(body, &concertDates)
	if err != nil {
		return nil, err
	}

	//fmt.Println("concertDates---------------", concertDates)

	return &concertDates, nil
}

func getCoordinates(city string) (string, string) {
	baseURL := "https://nominatim.openstreetmap.org/search"
	query := url.QueryEscape(city)
	url := fmt.Sprintf("%s?q=%s&format=json", baseURL, query)

	resp, err := http.Get(url)
	if err != nil {
		fmt.Println("Error:", err)
		return "", ""
	}
	defer resp.Body.Close()

	var locations []LocationPoint
	err = json.NewDecoder(resp.Body).Decode(&locations)
	if err != nil {
		fmt.Println("Error decoding JSON:", err)
		return "", ""
	}

	if len(locations) > 0 {
		return locations[0].Lat, locations[0].Lon
	}

	return "", ""
}

// Handlers pour les routes HTTP
func home(w http.ResponseWriter, r *http.Request) {
	// Récupérer la liste des artistes
	artists, err := getArtists()
	if err != nil {
		http.Error(w, "Erreur lors de la récupération des artistes", http.StatusInternalServerError)
		return
	}

	// Charger le fichier HTML de la page d'accueil
	tmpl, err := template.ParseFiles("Templates/index.html")
	if err != nil {
		http.Error(w, "Erreur lors du chargement du modèle", http.StatusInternalServerError)
		return
	}

	var dataArtist [52]ArtistDetail

	for i := 0; i < len(artists); i++ {
		dataArtist[i].ID = artists[i].ID
		dataArtist[i].Image = artists[i].Image
		dataArtist[i].Name = artists[i].Name
		dataArtist[i].Members = artists[i].Members
		dataArtist[i].CreationDate = artists[i].CreationDate
		dataArtist[i].FirstAlbum = artists[i].FirstAlbum
		data, err := getLocations(artists[i].ID)
		if err != nil {
			http.Error(w, "ID de l'artiste invalide", http.StatusBadRequest)
			return
		}

		dataArtist[i].Location = data.Locations

	}

	// Exécuter le modèle avec la liste des artistes
	err = tmpl.Execute(w, dataArtist)
	if err != nil {
		http.Error(w, "Erreur lors de l'exécution du modèle", http.StatusInternalServerError)
		return
	}
}

func detail(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID de l'artiste depuis les paramètres de requête
	artistID := r.URL.Query().Get("id")
	if artistID == "" {
		http.Error(w, "ID de l'artiste manquant dans la requête", http.StatusBadRequest)
		return
	}
	// Convertir l'ID de l'artiste en entier
	id, err := strconv.Atoi(artistID)
	if err != nil {
		http.Error(w, "ID de l'artiste invalide", http.StatusBadRequest)
		return
	}
	// Appeler la fonction getID pour obtenir les détails de l'artiste
	artist, err := getID(id)
	if err != nil {
		http.Error(w, "ID de l'artiste invalide", http.StatusBadRequest)
		return
	}
	locationArtist, err := getLocations(id)
	if err != nil {
		http.Error(w, "ID de l'artiste invalide", http.StatusBadRequest)
		return
	}
	concertDate, err := getConcertDattes(id)
	if err != nil {
		http.Error(w, "ID de l'artiste invalide", http.StatusBadRequest)
		return
	}
	//fmt.Println("liste concerdate", concertDate)
	var locations []LocationPoint

	for _, city := range locationArtist.Locations {
		lat, lon := getCoordinates(city)
		locations = append(locations, LocationPoint{Lat: lat, Lon: lon})
	}
	pointsJSON, err := json.Marshal(locations)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	fmt.Println(locations)
	var detailArtist ArtistDetail
	detailArtist.Name = artist.Name
	detailArtist.Image = artist.Image
	detailArtist.CreationDate = artist.CreationDate
	detailArtist.FirstAlbum = artist.FirstAlbum
	detailArtist.Members = artist.Members
	detailArtist.Location = locationArtist.Locations
	detailArtist.Dates = concertDate.Dates

	//fmt.Println("retour de la fonction getLocations", detailArtist)
	// Charger le fichier HTML du détail de l'artiste
	tmpl, err := template.ParseFiles("Templates/detail.html")
	if err != nil {
		http.Error(w, "Erreur lors du chargement du modèle", http.StatusInternalServerError)
		return
	}
	// Exécuter le modèle avec les données de l'artiste
	erro := tmpl.Execute(w, struct {
		ArtistDetail
		PointLocations template.JS
	}{
		ArtistDetail:   detailArtist,
		PointLocations: template.JS(pointsJSON),
	}) // Utiliser template.JS pour éviter l'échappement HTML})
	if erro != nil {
		http.Error(w, "Erreur lors de l'exécution du modèle", http.StatusInternalServerError)
		return
	}
}

func main() {
	// Définir les gestionnaire
	http.FileServer(http.Dir("Templates"))
	http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
	// Définir les autres routes
	http.HandleFunc("/", home)
	http.HandleFunc("/detail", detail)
	// Démarrer le serveur HTTP sur le port 8080
	fmt.Println("Server running on port 8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
