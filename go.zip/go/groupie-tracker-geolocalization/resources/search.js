
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const suggestionsList = document.getElementById('suggestions');
    const artistList = document.getElementById('artistList');
    
    function performSearch() {
        const searchQuery = searchInput.value.toLowerCase().trim();
        console.log("searchInput",searchQuery)
        suggestionsList.innerHTML = ''; // Effacer les suggestions précédentes

        if (searchQuery === '') {
            // Afficher tous les artistes si la recherche est vide
            artistList.querySelectorAll('.artist-item').forEach(function(item) {
                item.style.display = 'block';
            });
            return; // Sortir de la fonction si la barre de recherche est vide
        }

        const artistItems = artistList.querySelectorAll('.artist-item');
        artistItems.forEach(function(item) {
            const artistName = item.querySelector('h2').textContent.toLowerCase();
       
            const creationDate = item.querySelector('#datecreation > span').textContent.toLowerCase();
            const firstAlbum = item.querySelector('#firstAlbum > span').textContent.toLowerCase();
            const members = item.querySelectorAll('.members')
            const localisations = item.querySelectorAll('.location');
            let foundLocation = false; // Variable pour suivre si la recherche a été trouvée dans cet artiste
            let foundMember = false;
          
            members.forEach(function(membre) {
                const listmembre = membre.textContent.toLowerCase();
                if (listmembre.includes(searchQuery)) {
                    foundMember = true; // Marquer que la recherche a été trouvée
                        const suggestionItemDate = document.createElement('li');
                        suggestionItemDate.textContent = listmembre +' - member';
                        suggestionsList.appendChild(suggestionItemDate);
                    
                }
            });

            localisations.forEach(function(location) {
                const localisation = location.textContent.toLowerCase();
                if (localisation.includes(searchQuery)) {
                    foundLocation = true; // Marquer que la recherche a été trouvée
                        const suggestionItemDate = document.createElement('li');
                        suggestionItemDate.textContent = localisation +' - location';
                        suggestionsList.appendChild(suggestionItemDate);
                    
                }
            });
        

            if (artistName.includes(searchQuery) || foundMember || creationDate.includes(searchQuery) || firstAlbum.includes(searchQuery) || foundLocation) {
                
                if (artistName.includes(searchQuery)) {
                    const suggestionItemDate = document.createElement('li');
                    suggestionItemDate.textContent = artistName + ' - name/artist';
                    suggestionsList.appendChild(suggestionItemDate);
                }
                if (creationDate.includes(searchQuery)) {
                    const suggestionItemDate = document.createElement('li');
                    suggestionItemDate.textContent = creationDate + ' - creation date';
                   
                    suggestionsList.appendChild(suggestionItemDate);
                }

                // Créer une suggestion pour la date de création
                if (firstAlbum.includes(searchQuery)) {
                    const suggestionItemDate = document.createElement('li');
                    suggestionItemDate.textContent = firstAlbum + ' - first album';
                    suggestionsList.appendChild(suggestionItemDate);
                }

                    // Créer une suggestion pour la date de création
                
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }

    searchInput.addEventListener('input', performSearch);

    searchInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            performSearch();
        }
    });

    suggestionsList.addEventListener('click', function(event) {
        if (event.target.tagName === 'LI') {
            searchInput.value = event.target.textContent.split(' - ')[0].trim();
            performSearch();
        }
    });
});
