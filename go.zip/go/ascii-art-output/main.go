package main

import (
	"bufio"
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
)

// Fonction pour générer la représentation ASCII du texte en entrée
func generateAsciiArt(text string, ligne []string) (string, error) {
	var result strings.Builder
	var str []rune
	Newline := false // variable booléenne pour le contrôle des sauts de ligne

	for i, s := range text {
		if Newline {
			Newline = false
			result.WriteString("\n")
			AsciiPrint(str, ligne, &result)
			str = []rune{}
			continue
		}

		if s == '\\' && len(text) != i+1 {
			if text[i+1] == 'n' {
				Newline = true
				continue
			}
		}

		str = append(str, s)
	}

	AsciiPrint(str, ligne, &result)
	return result.String(), nil
}

// Fonction pour imprimer la représentation ASCII du texte en entrée
func AsciiPrint(str []rune, ligne []string, result *strings.Builder) {
	if len(str) != 0 {
		for j := 1; j <= 8; j++ {
			for _, s := range str {
				skip := (s - 32) * 9 // calculer la position dans le tableau
				result.WriteString(ligne[j+int(skip)])
			}
			result.WriteString("\n")
		}
	} else {
		result.WriteString("\n")
	}
}

func main() {
	// Vérifier le nombre d'arguments
	if len(os.Args) != 4 {
		fmt.Println("Usage: go run . [STRING] [BANNER]")
		fmt.Println("Example: go run . --output=<fileName.txt> something standard")
		return
	}
	// Déclaration des indicateurs
	outputFileName := flag.String("output", "", "Nom du fichier de sortie")

	// Analyser les indicateurs de ligne de commande
	flag.Parse()

	// Vérifier si l'indicateur --output est spécifié
	if *outputFileName == "" {
		fmt.Println("Usage: go run . --output=<fileName.txt> [STRING] [BANNER]")
		os.Exit(1)
	}

	// Vérifier s'il y a un argument [STRING]
	if flag.NArg() < 2 {
		fmt.Println("Usage: go run . --output=<fileName.txt> [STRING] [BANNER]")
		os.Exit(1)
	}

	// Récupérer la chaîne d'entrée
	inputString := flag.Arg(0)

	// Récupérer le nom du fichier de bannière et ouvrir le fichier
	bannerFileName := os.Args[3] + ".txt"
	bannerFile, err := os.Open(bannerFileName)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	defer bannerFile.Close()

	// Lire le contenu du fichier de bannière et transférer le contenu dans une slice
	var banner []string
	scanner := bufio.NewScanner(bannerFile)
	for scanner.Scan() {
		banner = append(banner, scanner.Text())
	}

	// Générer l'art ASCII
	asciiArtResult, err := generateAsciiArt(inputString, banner)
	if err != nil {
		fmt.Println("Erreur lors de la génération de l'art ASCII:", err)
		os.Exit(1)
	}

	// Ajouter un saut de ligne à la fin de l'art ASCII
	asciiArtResult += "\n"

	// Écrire le résultat dans le fichier spécifié
	err = ioutil.WriteFile(*outputFileName, []byte(asciiArtResult), 0644)
	if err != nil {
		fmt.Println("Erreur lors de l'écriture du fichier:", err)
		os.Exit(1)
	}

	fmt.Println("L'art ASCII a été généré avec succès et écrit dans le fichier", *outputFileName)
}
