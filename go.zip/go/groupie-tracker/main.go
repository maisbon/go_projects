package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
)

type Artists struct {
	Id            int      `json:"id"`
	Image         string   `json:"image"`
	Name          string   `json:"name"`
	Members       []string `json:"members"`
	CreationDate  int      `json:"creationDate"`
	IntfirstAlbum string   `json:"firstAlbum"`
	Locations     string   `json:"locations"`
	ConcertDates  string   `json:"concertDates"`
	Relations     string   `json:"relations"`
}

type ModelArtists struct {
	Id            int
	Image         string
	Name          string
	Members       []string
	CreationDate  int
	IntfirstAlbum string
	Locations     []string
	ConcertDates  []string
	Relations     map[string][]string
}
type Locations struct {
	Id           int      `json:"id"`
	Locations    []string `json:"locations"`
	ConcertDates string   `json:"dates"`
}

type ConcertDates struct {
	Id    int      `json:"id"`
	Dates []string `json:"dates"`
}

type Relations struct {
	ID             int                 `json:"id"`
	DatesLocations map[string][]string `json:"datesLocations"`
}

func main() {

	type FormData struct {
		Artist []ModelArtists
	}
	home := func(w http.ResponseWriter, r *http.Request) {

		if r.Method == "GET" && r.URL.Path == "/" {
			resp, error := http.Get(`https://groupietrackers.herokuapp.com/api/artists`)
			if error != nil {
				log.Fatalln(error)
			}
			//Nous lisons le corps de la réponse body
			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				log.Fatalln(err)
			}
			//Convertir body (donnée des artists en json) en une
			var listArtist []Artists
			err = json.Unmarshal(body, &listArtist)
			if err != nil {
				fmt.Println("Erreur lors de la désérialisation JSON:", err)
				return
			}

			//fmt.Println(len(listArtist))
			//var response Locations
			//je parcours la liste des artistes pour aller trouver les localisations et les date de concert
			var tab []ModelArtists
			for i := 0; i < len(listArtist); i++ {
				oneArtist := listArtist[i]
				resultat := sendData(oneArtist)
				tab = append(tab, resultat)
			}
			//fmt.Println("tab", tab)

			data := FormData{
				Artist: tab,
			}
			tmpl := template.Must(template.ParseFiles("Templates/index.html"))
			errs := tmpl.Execute(w, data)

			if errs != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
		} else {
			http.NotFound(w, r)

		}

	}
	http.HandleFunc("/", home)
	http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func sendData(artist Artists) ModelArtists {
	var newArtist ModelArtists
	/*********recuperer les localisations  des concert de l'artits ***************/
	res, error := http.Get(artist.Locations)
	if error != nil {
		log.Fatalln(error)
	}
	//Nous lisons le corps de la réponse body
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Fatalln(err)
	}
	//Convertir body (donnée des artists en json) en une
	var listLocation Locations
	err = json.Unmarshal(body, &listLocation)
	if err != nil {
		fmt.Println("Erreur lors de la désérialisation JSON:", err)
	}
	/*********recuperer les dates des concerts***************/
	resdate, error := http.Get(listLocation.ConcertDates)
	//Nous lisons le corps de la réponse body
	bodyDate, error := ioutil.ReadAll(resdate.Body)
	if err != nil {
		log.Fatalln(error)
	}
	//Convertir body (donnée des artists en json) en une
	var listDate ConcertDates
	err = json.Unmarshal(bodyDate, &listDate)
	if err != nil {
		fmt.Println("Erreur lors de la désérialisation JSON:", err)
	}
	/****************recuperer la relation en les localisations et les dates des concerts *******************/

	resRelation, error := http.Get(artist.Relations)
	//Nous lisons le corps de la réponse body
	bodyRelation, error := ioutil.ReadAll(resRelation.Body)
	if err != nil {
		log.Fatalln(error)
	}
	//Convertir body (donnée des artists en json) en une
	var listRelation Relations
	err = json.Unmarshal(bodyRelation, &listRelation)
	if err != nil {
		fmt.Println("Erreur lors de la désérialisation JSON:", err)
	}
	/*************************affectation des données dans ma variable newartist************************/
	newArtist.Id = artist.Id
	newArtist.Name = artist.Name
	newArtist.Image = artist.Image
	newArtist.IntfirstAlbum = artist.IntfirstAlbum
	newArtist.Members = artist.Members
	newArtist.CreationDate = artist.CreationDate
	newArtist.Locations = listLocation.Locations
	newArtist.ConcertDates = listDate.Dates
	newArtist.Relations = listRelation.DatesLocations
	return newArtist

}
