# net-cat


### How to run:

1. Run the **go build TCPChat.go** command in the root directory of the project
2. Run the **./TCPChat $port**

### Description

Ce projet consiste à recréer NetCat dans une architecture serveur-client qui peut s’exécuter en mode serveur sur un port spécifié à l’écoute des connexions entrantes, et il peut être utilisé en mode client, en essayant de se connecter à un port spécifié et en transmettant des informations au serveur.


   * NetCat, commande système nc, est un utilitaire de ligne de commande qui lit et écrit des données sur des connexions réseau à l’aide de TCP ou UDP. Il est utilisé pour tout ce qui concerne les sockets de domaine TCP, UDP ou UNIX, il est capable d’ouvrir des connexions TCP, d’envoyer des paquets UDP, d’écouter sur des ports TCP et UDP arbitraires et bien plus encore.

Net-cat crée un chat de groupe via TCP. Le projet dispose des fonctionnalités suivantes :

   * Connexion TCP entre le serveur et plusieurs clients (relation de 1 à plusieurs).
   * Une exigence de nom pour le client.
   * Contrôler la quantité de connexions.
   * Les clients doivent pouvoir envoyer des messages au clavardage.
   * Ne diffusez pas de messages VIDES à partir d’un client.
   * Les messages envoyés doivent être identifiés par l’heure à laquelle ils ont été envoyés et par le nom d’utilisateur du destinataire, par exemple : [2020-01-20 15:48:41][client.name]:[client.message]
   * Si un client se joint au clavardage, tous les messages précédents envoyés au clavardage doivent être téléversés au nouveau client.
   * Si un client se connecte au serveur, le reste des clients * doivent être informés par le serveur que le client a rejoint le groupe.
   * Si un client quitte le chat, le reste des clients doit être informé par le serveur que le client a quitté.
   * Tous les clients doivent recevoir les messages envoyés par d’autres clients.
   * Si un client quitte le chat, le reste des clients ne doit pas se déconnecter.
   * S’il n’y a pas de port spécifié, définissez par défaut le port 8989. Sinon, le programme doit répondre avec un message d’utilisation : [USAGE] : . /TCPChat $port

* Start TCP server, listen and accept connections
* The project has Go-routines
* The project has channels and Mutexes
* Accepts maximum 10 connections


### Packages
* Seule les bibliothèque permise ont été utilisées

### Usage

    Serveur: 
    $ go run .
    Ecoute sur le port :8989
    $ go run . 2525
    Ecoute sur le port :2525
    $ go run . 2525 localhost
    [USAGE]: ./TCPChat \$port
    $

    The client :

    $ nc $IP $port


    
    Client1:
    $ nc localhost 2525


![alt text](ex-net.png "net-cat")​

