

```bash
    go run cmd/main.go
```

- with docker

```bash
    docker build -t forum .
    docker run -p 8183:8183 forum
```

- server route

```
    http://localhost:8183
```

</details>

<details>
<summary>Technical Requirements</summary>

## Exigences techniques du forum

### Author


### Objectifs

Ce projet consiste à créer un *forum web* qui permet :

- la communication entre utilisateurs ;
- associer des catégories aux publications ;
- aimer et ne pas aimer les publications et Commentairesaires ;
- filtrage des posts.

#### SQLite


Afin de stocker les données de votre forum (comme les utilisateurs, les publications, les Commentairesaires, etc.), vous utiliserez la bibliothèque de bases de données SQLite.

SQLite est un choix populaire en tant que logiciel de base de données intégré pour le stockage local/client dans des logiciels d'application tels que les navigateurs Web. Il vous permet de créer une base de données ainsi que de la contrôler à l'aide de requêtes.

Pour structurer votre base de données et obtenir de meilleures performances, nous vous conseillons vivement de jeter un œil au **schéma de relation d'entité** et d'en créer un basé sur votre propre base de données.

- Vous devez utiliser au moins une requête *SELECT*, une *CREATE* et une *INSERT*.

Pour en savoir plus sur SQLite, vous pouvez consulter la [page SQLite](https://www.sqlite.org/index.html).

#### Authentication

Dans ce segment, le client doit pouvoir « s'inscrire » en tant que nouvel utilisateur sur le forum, en saisissant ses informations d'identification. Vous devez également créer une « session de connexion » pour accéder au forum et pouvoir ajouter des messages et des Commentairesaires.

Vous devez utiliser des *cookies pour permettre à chaque utilisateur de n'avoir qu'une seule session ouverte*. Chacune de ces sessions doit contenir une *date d'expiration*. C'est à vous de décider combien de temps le cookie reste « vivant ». L'utilisation de *UUID* est un bonus.

##### Instruction pour l'enregistrement des utilisateurs :

 Doit demander *email*
	- Lorsque l'email est déjà pris, renvoyez une réponse d'erreur.
- Doit demander *nom d'utilisateur*
- Doit demander *mot de passe*
	- Le mot de passe doit être crypté lors de son stockage (Bonus). 

Le forum doit pouvoir vérifier si l'email fourni est présent dans la base de données et que tous les identifiants sont corrects. Il doit vérifier si le mot de passe fourni est le même que celui stocké dans la base de données. Si les mots de passe ne correspondent pas, il doit renvoyer une réponse d'erreur.

#### Communication

Pour que les utilisateurs puissent communiquer entre eux, ils devront pouvoir créer des posts et des Commentairesaires.

- Seuls les utilisateurs enregistrés pourront créer des publications et des Commentairesaires ;
- Lorsque les utilisateurs enregistrés créent une publication, ils peuvent y associer une ou plusieurs catégories ;
	- La mise en place et le choix des catégories vous appartiennent.
- Les posts et Commentairesaires doivent être visibles par tous les utilisateurs (enregistrés ou non) ;
- Les utilisateurs non enregistrés ne pourront voir que les publications et les Commentairesaires.

#### Likes and dislikes

Seuls les utilisateurs enregistrés pourront aimer ou ne pas aimer les publications et Commentairesaires.

Le nombre de likes et de dislikes doit être visible par tous les utilisateurs (enregistrés ou non).

#### Filters

Vous devez implémenter un mécanisme de filtrage, qui permettra aux utilisateurs de filtrer les publications affichées par :

- catégories ;
- messages créés;
- les articles aimés.

Vous pouvez consulter le filtrage par catégories sous forme de sous-forums. Un sous-forum est une section d'un forum en ligne dédiée à un sujet spécifique.

Notez que les deux derniers ne sont disponibles que pour les utilisateurs enregistrés et doivent faire référence à l'utilisateur connecté.

#### Docker

Pour le projet de forum, vous devez utiliser *Docker*.

### Instructions

- Vous devez utiliser **SQLite** ;
- Vous devez gérer les erreurs du site Web, le statut HTTP ;
- Vous devez gérer toutes sortes d'erreurs techniques ;
- Le code doit respecter les **bonnes pratiques** ;
- Il est recommandé d'avoir des **fichiers de test** pour les *tests unitaires*.

### Forfaits autorisés

- Tous les forfaits Go standards sont autorisés
- *sqlite3*
- *bcrypt*
- *UUID*

> Vous ne devez utiliser aucune bibliothèque ou framework fronté comme React, Angular, Vue etc.

Ce projet vous aidera à en apprendre davantage sur :

- Les bases du web :
	-HTML
	-HTTP
	- Sessions et cookies

- Utilisation et configuration de Docker
	- Conteneuriser une application
	- Compatibilité/Dépendance
	- Création d'images

- Langage SQL
	- Manipulation de bases de données

- Les bases du cryptage

</details>
