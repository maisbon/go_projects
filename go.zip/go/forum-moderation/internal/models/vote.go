package models

const (
	VoteLike    = 1
	VoteDislike = -1
)
