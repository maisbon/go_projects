package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
)

var colors = map[string]string{
	"black":         "\033[30m",
	"red":           "\033[31m",
	"green":         "\033[32m",
	"yellow":        "\033[33m",
	"blue":          "\033[34m",
	"magenta":       "\033[35m",
	"cyan":          "\033[36m",
	"white":         "\033[37m",
	"gray":          "\033[90m",
	"light_red":     "\033[91m",
	"light_green":   "\033[92m",
	"light_yellow":  "\033[93m",
	"light_blue":    "\033[94m",
	"light_magenta": "\033[95m",
	"light_cyan":    "\033[96m",
	"light_white":   "\033[97m",
	"orange":        "\033[38;5;208m",
	"violet":        "\033[38;5;165m",
	"pink":          "\033[38;5;218m",
	"sky_blue":      "\033[38;5;45m",
	"olive_green":   "\033[38;5;100m",
	"olive_yellow":  "\033[38;5;142m",
	"turquoise":     "\033[38;5;80m",
	"lavender":      "\033[38;5;183m",
	"lime":          "\033[38;5;148m",
	"salmon":        "\033[38;5;173m",
}

func Ascii(word, templ, color, letters string) {
	for i := 0; i < len(word); i++ {
		if (word[i] < 32 || word[i] > 127) && word[i] != 10 {
			fmt.Println("Entrée incorrecte.")
			return
		}
	}

	template, err := ioutil.ReadFile(templ + ".txt")
	if err != nil {
		fmt.Println(err)
		return
	}

	splitted := strings.Split(string(template), "\n\n")
	if len(splitted) != 95 {
		fmt.Println("Template incorrect :", len(splitted), "au lieu de 95")
		return
	}

	lines := strings.Split(word, "\n")
	res := ""

	for _, line := range lines {
		if line == "" && res != "" {
			res += string('\n')
			continue
		}

		for row := 0; row < 8; row++ {
			for d := 0; d < len(line); d++ {
				ch := line[d]
				if ch == letters[0] {
					if strings.HasPrefix(line[d:], letters) {
						for i := d; i < d+len(letters); i++ {
							temp := fmt.Sprintf("%s%s\033[0m", color, strings.Split(splitted[line[i]-32], "\n")[row])
							res += temp
						}
						d += len(letters) - 1
					} else {
						res += strings.Split(splitted[ch-32], "\n")[row]
					}
				} else {
					res += strings.Split(splitted[ch-32], "\n")[row]
				}
			}
			res += string('\n')
		}
	}

	fmt.Print(res)
}

func main() {
	colorPtr := flag.String("color", "", "Specify a color for the ASCII art")
	flag.Parse()

	if len(os.Args) != 1 {
		col := os.Args[1]
		if len(col) < 8 || col[:8] != "--color=" {
			fmt.Println("Usage: go run . [OPTION] [STRING]\n\nEX: go run . --color=<color> <letters to be colored>", "something")
			return
		}
	}

	// Vérifie le nombre d'arguments
	if flag.NArg() < 1 {
		fmt.Println("Usage: go run . [OPTION] [STRING]\n\nEX: go run . --color=<color> <letters to be colored>", "something")
		return
	}

	// Vérifie si la couleur	 est spécifiée
	if *colorPtr == "" {
		fmt.Println("Usage: go run . --color=<color> <text>")
		return
	}

	// Vérifie si la couleur est disponible
	color, ok := colors[*colorPtr]
	if !ok {
		fmt.Println("Cette couleur n'est pas disponible :", *colorPtr)
		return
	}

	arg := flag.Args()
	// Récupère le texte à convertir en ASCII art
	word := arg[len(arg)-1]
	letter := arg[0]

	word = strings.ReplaceAll(word, "\\n", "\n")

	if letter == "" {
		letter = word
	}

	// Appelle la fonction Ascii avec les valeurs des flags
	Ascii(word, "standard", color, letter)
}
