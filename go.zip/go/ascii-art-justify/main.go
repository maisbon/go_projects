package main

import (
	"bufio"
	"flag"
	"fmt"
	"os"
	"strings"
	"syscall"
	"unsafe"
)

func getTerminalWidth() (int, error) {
	winsize := struct {
		Row    uint16
		Col    uint16
		Xpixel uint16
		Ypixel uint16
	}{}

	_, _, err := syscall.Syscall(syscall.SYS_IOCTL, uintptr(syscall.Stdout), uintptr(syscall.TIOCGWINSZ), uintptr(unsafe.Pointer(&winsize)))
	if err != 0 {
		return 0, err
	}
	return int(winsize.Col), nil
}

func main() {
	// Vérifier le nombre d'arguments
	if len(os.Args) != 4 {
		fmt.Println("Usage: go run .  [OPTION] [STRING] [BANNER]")
		fmt.Println("Example: go run . --align=right  something  standard")
		return
	}
	// Déclaration d'un drapeau pour l'alignement
	alignType := flag.String("align", "left", "Type d'alignement: center, left, right, justify")
	// Parsing des drapeaux
	flag.Parse()
	width, err := getTerminalWidth()
	// Récupération du nom du fichier de bannière et son ouverture
	osfichier := os.Args[3] + ".txt"
	fichier, err := os.Open(osfichier)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer fichier.Close()
	// Lecture du contenu et transfert du contenu dans une slice
	var banniere []string
	scanner := bufio.NewScanner(fichier)
	for scanner.Scan() {
		banniere = append(banniere, scanner.Text())
	}
	// Récupération du texte à afficher via la ligne de commande
	argu := os.Args[2:]
	argcoupe := argu[:len(argu)-1]
	argutilise := strings.Join(argcoupe, " ")
	// Appel de la fonction AsciiArt avec l'alignement spécifié
	texte := AsciiArt(argutilise, banniere, *alignType, width)
	fmt.Println(texte)
}

// Fonction pour générer l'ASCII art avec un alignement spécifié
func AsciiArt(argutilise string, contenutxt []string, alignType string, terminalSize int) string {
	var builder strings.Builder
	lignetxt := strings.Split(argutilise, "\\n")
	for i, lettre := range lignetxt {
		if len(lettre) == 0 && i == len(lignetxt)-1 {
			continue
		}
		if len(lettre) == 0 {
			builder.WriteString("\n")
			continue
		}
		for j := 0; j < 8; j++ {
			// Calcul de la largeur de la ligne
			width := len(lettre) * 9
			// Alignement
			padding := 0
			switch alignType {
			case "center":
				padding = (terminalSize - width) / 2
			case "left":
				// Ne rien faire, garder l'alignement à gauche
			case "right":
				padding = terminalSize - width

			case "justify":
				// Calculer l'espacement pour justifier le texte
				if len(lignetxt) > 1 && i < len(lignetxt)-1 {
					extraSpaces := (150 - width) / (len(lettre) - 1)
					padding = extraSpaces
					if padding < 0 {
						padding = 0
					}
				}
			default:
				fmt.Println("Type d'alignement non valide. Utilisez l'une des valeurs suivantes : center, left, right, justify.")
				os.Exit(1)
			}

			// Appliquer l'alignement
			if padding > 0 {
				builder.WriteString(strings.Repeat(" ", padding))
			} else if padding < 0 {
				// Si padding est négatif, ajoutez l'espace à droite pour maintenir l'alignement à gauche
				builder.WriteString(strings.Repeat(" ", -padding))
			}

			// Vérifier la longueur de la lettre avant d'accéder à la bannière
			if len(lettre) > 0 {
				for _, char := range lettre {
					pos := 1 + (int(char)-32)*9 + j
					// Vérifier la position avant d'accéder à la bannière
					if pos >= 0 && pos < len(contenutxt) {
						builder.WriteString(contenutxt[pos])
					}
				}
			}
			// Ajouter un saut de ligne sauf pour la dernière ligne du dernier segment
			if !(i == len(lignetxt)-1 && j == 7) {
				builder.WriteString("\n")
			}
		}
	}
	return builder.String()
}
