# ASCII Art JUSTIFY

## Description

Ce programme en Go permet d'aligner du texte en fonction de différents types d'alignement. Il prend en charge les options suivantes :

- `--align=center`: Aligner le texte au centre.
- `--align=left`: Aligner le texte à gauche (par défaut).
- `--align=right`: Aligner le texte à droite.
- `--align=justify`: Justifier le texte.

## Auteurs

- malarissa
- rekouakou


## Installation et utilisation 

1. Clonez le dépôt Git sur votre machine locale.
2. Installez Go sur votre machine si ce n'est pas déjà fait.
3. Ouvrez un terminal et naviguez vers le répertoire du projet.
4. go run . --align=<type> [STRING] [BANNER]
5. go run . --align=right something standard
6. Pour tester le code il faudra jouer sur la résolution de l'écran




    
	
