package main

import (
    "flag"
    "fmt"
    "my-ls-1/internal/ls"
    "os"
)

func main() {
    // Définir les flags
    long := flag.Bool("l", false, "utiliser un format de liste longue")
    recursive := flag.Bool("R", false, "lister récursivement les sous-répertoires")
    all := flag.Bool("a", false, "inclure les entrées de répertoire dont les noms commencent par un point")
    reverse := flag.Bool("r", false, "inverser l'ordre de tri")
    sortByTime := flag.Bool("t", false, "trier par heure de modification, les plus récents en premier")

    // Parser les flags
    flag.Parse()

    // Récupérer le répertoire cible
    target := "."
    if len(flag.Args()) > 0 {
        target = flag.Arg(0)
    }

    // Appeler la fonction ls avec les flags
    err := ls.MyLS(target, *long, *recursive, *all, *reverse, *sortByTime)
    if err != nil {
        fmt.Println("Erreur :", err)
        os.Exit(1)
    }
}
