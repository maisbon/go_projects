// internal/ls/utils.go
package ls

import "os"

// ReverseSlice reverses the order of the slice of directory entries.
func ReverseSlice(files []os.DirEntry) {
    for i, j := 0, len(files)-1; i < j; i, j = i+1, j-1 {
        files[i], files[j] = files[j], files[i]
    }
}
