package ls

import (
    "fmt"
    "os"
    "sort"
    "time"
    "syscall"
)

func MyLS(target string, long, recursive, all, reverse, sortByTime bool) error {
    files, err := os.ReadDir(target)
    if err != nil {
        return err
    }

    // Filtrer les fichiers si le flag -a n'est pas présent
    if !all {
        var filteredFiles []os.DirEntry
        for _, file := range files {
            // Exclure les fichiers dont le nom commence par un point
            if file.Name()[0] != '.' {
                filteredFiles = append(filteredFiles, file)
            }
        }
        files = filteredFiles
    }

    // Trier les fichiers selon les flags
    if sortByTime {
        sort.Slice(files, func(i, j int) bool {
            infoI, _ := files[i].Info()
            infoJ, _ := files[j].Info()
            return infoI.ModTime().After(infoJ.ModTime())
        })
    } else {
        sort.Slice(files, func(i, j int) bool {
            return files[i].Name() < files[j].Name()
        })
    }

    // Inverser l'ordre si le flag -r est activé
    if reverse {
        reverseSlice(files)
    }

    // Afficher les fichiers
    for _, file := range files {
        if long {
            displayLongFormat(target, file)
        } else {
            fmt.Println(file.Name())
        }
    }

    // Effectuer une liste récursive si le flag -R est activé
    if recursive {
        for _, file := range files {
            if file.IsDir() {
                fmt.Println("\n" + target + "/" + file.Name() + ":")
                MyLS(target+"/"+file.Name(), long, recursive, all, reverse, sortByTime)
            }
        }
    }

    return nil
}

// Fonction pour inverser l'ordre des fichiers
func reverseSlice(files []os.DirEntry) {
    for i, j := 0, len(files)-1; i < j; i, j = i+1, j-1 {
        files[i], files[j] = files[j], files[i]
    }
}


func displayLongFormat(target string, file os.DirEntry) {
    info, _ := file.Info()
    modTime := info.ModTime().Format(time.RFC822)
    
    stat := info.Sys().(*syscall.Stat_t)
    
    fmt.Printf("%-10s %3d %8d %8d %8d %s %s\n",
        info.Mode().String(),
        1, // nombre de liens (simplifié pour l'exemple)
        stat.Uid, // UID du propriétaire
        stat.Gid, // GID du groupe
        info.Size(),
        modTime,
        file.Name(),
    )
}


