package ls

import (
    "flag"
)

// DefineFlags initialise et retourne les options en ligne de commande.
func DefineFlags() (long, recursive, all, reverse, sortByTime *bool) {
    long = flag.Bool("l", false, "utiliser un format de liste longue")
    recursive = flag.Bool("R", false, "lister récursivement les sous-répertoires")
    all = flag.Bool("a", false, "inclure les entrées de répertoire dont les noms commencent par un point")
    reverse = flag.Bool("r", false, "trier en ordre inverse")
    sortByTime = flag.Bool("t", false, "trier par date de modification, les plus récents en premier")

    return
}
