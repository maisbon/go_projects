## my-ls-1
Description
my-ls-1 est une réimplémentation personnalisée de la commande Unix ls, écrite en Go. Cette commande liste les fichiers et dossiers d'un répertoire spécifié ou du répertoire courant si aucun n'est spécifié. La commande prend en charge plusieurs options similaires à celles de ls.

## Fonctionnalités
Liste les fichiers et dossiers d'un répertoire.
Supporte les options -l, -R, -a, -r, et -t.
Options
-l : Utilise un format de liste longue.
-R : Liste récursivement les sous-répertoires.
-a : Inclut les entrées de répertoire dont les noms commencent par un point.
-r : Trie en ordre inverse.
-t : Trie par date de modification, les plus récents en premier.

## Structure du projet

my-ls-1/
├── cmd/
│   └── my-ls/
│       └── main.go
├── internal/
│   └── ls/
│       ├── ls.go
│       ├── flags.go
│       └── utils.go
├── tests/
│   ├── ls_test.go
│   └── flags_test.go
├── README.md
└── go.mod

## Installation
Clonez le dépôt :
git clone https://academy.digifemmes.com/git/malarissa/my-ls-1.git
cd my-ls-1

## Initialisez le module Go :
go mod tidy

## Utilisation
Pour exécuter le programme, utilisez la commande suivante :

go run cmd/my-ls/main.go [OPTIONS] [DIRECTORY]
Exemples :

## Liste les fichiers du répertoire courant :

## Liste les fichiers avec les détails :
go run cmd/my-ls/main.go -l

## Liste les fichiers, y compris les fichiers cachés :
go run cmd/my-ls/main.go -l
## Liste les fichiers de manière récursive :
 go run cmd/my-ls/main.go -R

## Liste les fichiers par date de modification :
go run cmd/my-ls/main.go -t

## Tests
Pour exécuter les tests unitaires, utilisez la commande suivante :
go test ./tests/...

## Bonnes pratiques
Le code doit respecter les bonnes pratiques de codage en Go.
Il est recommandé d'écrire des fichiers de test pour les tests unitaires.
L'utilisation du package os/exec est interdite dans le code de my-ls.

