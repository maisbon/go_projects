// tests/flags_test.go
package tests

import (
    "flag"
    "my-ls-1/internal/ls"
    "testing"
)

func TestDefineFlags(t *testing.T) {
    // Initialiser les flags
    long, recursive, all, reverse, sortByTime := ls.DefineFlags()
    flag.CommandLine = flag.NewFlagSet("test", flag.ContinueOnError)

    // Définir les flags pour le test
    flag.Set("l", "true")
    flag.Set("R", "true")
    flag.Set("a", "true")
    flag.Set("r", "true")
    flag.Set("t", "true")

    // Vérifier les valeurs des flags
    if *long != true {
        t.Errorf("expected true, got %v", *long)
    }
    if *recursive != true {
        t.Errorf("expected true, got %v", *recursive)
    }
    if *all != true {
        t.Errorf("expected true, got %v", *all)
    }
    if *reverse != true {
        t.Errorf("expected true, got %v", *reverse)
    }
    if *sortByTime != true {
        t.Errorf("expected true, got %v", *sortByTime)
    }
}
