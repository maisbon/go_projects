// tests/ls_test.go
package tests

import (
    "my-ls-1/internal/ls"
    "os"
    "testing"
)

func TestMyLS(t *testing.T) {
    // Configuration du test
    dir := "testdata"
    os.Mkdir(dir, 0755)
    defer os.RemoveAll(dir)
    os.Create(dir + "/file1")
    os.Create(dir + "/file2")
    os.Mkdir(dir+"/subdir", 0755)
    os.Create(dir + "/subdir/file3")

    // Exécuter la commande ls avec différentes options
    err := ls.MyLS(dir, false, false, false, false, false)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }

    err = ls.MyLS(dir, true, false, false, false, false)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }

    err = ls.MyLS(dir, false, true, false, false, false)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }

    err = ls.MyLS(dir, false, false, true, false, false)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }

    err = ls.MyLS(dir, false, false, false, true, false)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }

    err = ls.MyLS(dir, false, false, false, false, true)
    if err != nil {
        t.Errorf("MyLS() error = %v", err)
    }
}
