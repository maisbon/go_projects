package main

import (
	"Forum/controllers"
	"fmt"
	"net/http"
)

func main() {
	port := ":8081"
	fmt.Println("Lancement du serveur web à l'adresse (http://localhost:8081)")

	http.HandleFunc("/", handleRoute)

	

	// Serveur de fichiers statiques
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	http.ListenAndServe(port, nil)
}


func handleRoute(w http.ResponseWriter, r *http.Request) {
	switch r.URL.Path {
	case "/":
		controllers.Home(w, r)
	case "/register":
		controllers.Registerpage(w, r)
	case "/seconnecter":
		controllers.Loginpage(w, r)
	case "/motdepasseoublie":
		controllers.Verifypage(w, r)
	case "/reinitialiser":
		controllers.Updatepage(w, r)
	case "/signup":
		controllers.Signup(w, r)
	case "/signin":
		controllers.Signin(w, r)
	case "/profile":
		controllers.Profile(w, r)
	case "/verify":
		controllers.Verification(w, r)
	case "/Update":
		controllers.Update(w, r)
	case "/Deconnexion":
		controllers.Logout(w,r)
	default:
		controllers.Erreur(w, r, http.StatusNotFound)
	}
}