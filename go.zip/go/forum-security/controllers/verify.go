package controllers

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
)

func Verification(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		// Méthode non autorisée, gérer en conséquence
		http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed)
		return
	}

	r.ParseForm()
	email := r.Form.Get("email")
	username := r.Form.Get("username")

	if isExistUser(email, username) {
		// Rediriger vers la page de réinitialisation du mot de passe
		successMessage := "Individu trouvé, reinitialisez le mot de passe !"

	http.Redirect(w, r, fmt.Sprintf("/reinitialiser?message=%s", successMessage), http.StatusFound)

		return
	}

	// Redirection vers la page de connexion avec un message de réussite dans un pop-up
	echecMessage := "Individu non trouvé !"

	http.Redirect(w, r, fmt.Sprintf("/motdepasseoublie?message=%s", echecMessage), http.StatusFound)
}

func isExistUser(email, username string) bool {
	db, err := sql.Open("sqlite3", "Forum.db")
	if err != nil {
		log.Fatal(err)
		Erreur(nil,nil,http.StatusInternalServerError)
	}
	defer db.Close()

	// Requête SQL pour récupérer l'utilisateur avec l'email donné
	var storeUsername string
	err = db.QueryRow("SELECT username FROM T_utilisateur WHERE email = ?", email).Scan(&storeUsername)
	if err != nil {
		if err == sql.ErrNoRows {
			// Aucun utilisateur trouvé avec cet email
			return false
		}
		log.Fatal(err)
		Erreur(nil,nil,http.StatusInternalServerError)
	}

	if username == storeUsername {
		return true
	}

	return false
}