package controllers

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"text/template"
	"time"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

var sessions = make(map[string]string) // Map pour stocker les sessions avec l'identifiant de session comme clé et l'identifiant de l'utilisateur comme valeur

func setSessionCookie(w http.ResponseWriter, sessionID, userID string) {
	// Créer un cookie avec l'identifiant de session
	cookie := http.Cookie{
		Name:     "sessionID",
		Value:    sessionID,
		Expires:  time.Now().Add(24 * time.Hour), // Exemple: cookie valide pendant 24 heures
		HttpOnly: true,
	}

	// Définir le cookie dans la réponse HTTP
	http.SetCookie(w, &cookie)

	// Vous pouvez également stocker l'ID de l'utilisateur dans le cookie de session si nécessaire
	userCookie := http.Cookie{
		Name:     "userID",
		Value:    userID,
		Expires:  time.Now().Add(24 * time.Hour), // Exemple: cookie valide pendant 24 heures
		HttpOnly: true,
	}

	// Définir le cookie utilisateur dans la réponse HTTP
	http.SetCookie(w, &userCookie)
}

func Signin(w http.ResponseWriter, r *http.Request) {
    // Vérifiez si la méthode est POST
    if r.Method != "POST" {
        // Si ce n'est pas le cas, chargez le template de la page de connexion
        tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/Login.html"))
        // Envoyez le template avec le titre de la page et un message d'erreur vide
        if err := tmpl.ExecuteTemplate(w, "base.html", struct {
            Title       string
            ErrorMessage string
        }{Title: "Connexion", ErrorMessage: ""}); err != nil {
            Erreur(w,r,http.StatusInternalServerError)
            return
        }
        return
    }

    email := r.FormValue("email")
    password := r.FormValue("password")

    var errorMessage string
    var title string

    // Vérification des champs requis
    if email == "" || password == "" {
        // Afficher un message d'erreur sur la page de connexion
        errorMessage = "Veuillez remplir tous les champs"
        title = "Connexion"
    } else if !isValidEmail(email) {
        // Afficher un message d'erreur sur la page de connexion
        errorMessage = "Adresse e-mail invalide"
        title = "Connexion"
    } else if isValidUser(email, password) {
        // Authentification réussie, générez un identifiant de session
        sessionID := generateSessionID()

        // Récupérez l'identifiant de l'utilisateur à partir de la base de données
        userID, err := getUserIDFromEmail(email)
        if err != nil {
            Erreur(w,r,http.StatusInternalServerError)
        }

        // Stockez l'identifiant de session et l'ID de l'utilisateur dans un cookie
        setSessionCookie(w, sessionID, userID)

        // Redirigez l'utilisateur vers la page de profil
        http.Redirect(w, r, "/profile", http.StatusFound)
        return
    } else {
        // Authentification échouée, afficher un message d'erreur sur la page de connexion
        errorMessage = "Identifiants invalides"
        title = "Connexion"
    }

    // Chargez le template de la page de connexion avec le message d'erreur approprié
    tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/Login.html"))
    // Envoyez le template avec le titre de la page et le message d'erreur approprié
    if err := tmpl.ExecuteTemplate(w, "base.html", struct {
        Title       string
        ErrorMessage string
    }{Title: title, ErrorMessage: errorMessage}); err != nil {
        Erreur(w,r,http.StatusInternalServerError)
        return
    }
}



func getUserIDFromEmail(email string) (string, error) {
	// Ouvrir la connexion à la base de données
	db, err := sql.Open("sqlite3", "Forum.db")
	if err != nil {
		return "", err
	}
	defer db.Close()

	// Requête SQL pour récupérer l'identifiant de l'utilisateur avec l'email donné
	var userID string
	err = db.QueryRow("SELECT id_util FROM T_utilisateur WHERE email = ?", email).Scan(&userID)
	if err != nil {
		return "", err
	}

	return userID, nil
}

func generateSessionID() string {
	// Générer un nouvel UUID pour la session
	sessionID := uuid.New()

	return sessionID.String()
}

func isValidUser(email, password string) bool {
	// Ouvrir la connexion à la base de données
	db, err := connectToDatabase()
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Requête SQL pour récupérer l'utilisateur avec l'email donné
	var storedPassword string
	err = db.QueryRow("SELECT mot_de_passe FROM T_utilisateur WHERE email = ?", email).Scan(&storedPassword)
	if err != nil {
		if err == sql.ErrNoRows {
			// Aucun utilisateur trouvé avec cet email
			return false
		}
		log.Fatal(err)
		Erreur(nil,nil,http.StatusInternalServerError)
	}

	// Vérifier si le mot de passe fourni correspond au mot de passe hashé stocké
	err = bcrypt.CompareHashAndPassword([]byte(storedPassword), []byte(password))
	if err != nil {
		// Mot de passe incorrect
		return false
	}


	// Mot de passe correct, les informations d'identification sont valides
	return true
}

func Profile(w http.ResponseWriter, r *http.Request) {
	// Récupérer les cookies de session
	sessionCookie, err := r.Cookie("sessionID")
	if err != nil {
		// Gérer l'erreur
		http.Error(w, "Cookie de session introuvable", http.StatusUnauthorized)
		return
	}

	userCookie, err := r.Cookie("userID")
	if err != nil {
		// Gérer l'erreur
		http.Error(w, "Cookie d'utilisateur introuvable", http.StatusUnauthorized)
		return
	}

	// Extraire les valeurs des cookies de session
	sessionID := sessionCookie.Value
	fmt.Println(sessionID)
	userID := userCookie.Value
	fmt.Println(userID)

	// Utiliser les valeurs extraites pour récupérer les données d'utilisateur nécessaires
	userData, err := getUserDataByID(userID)
	if err != nil {
		// Gérer l'erreur
		http.Error(w, "Impossible de récupérer les données utilisateur", http.StatusInternalServerError)
		return
	}
	fmt.Println(userData)

	tmpl := template.Must(template.ParseFiles("templates/Auth/Session.html"))
	if err := tmpl.Execute(w, userData); err != nil {
		Erreur(w,r,http.StatusInternalServerError)
		return
	}
	fmt.Println("effectué avec succes")
}

type UserData struct {
	Title    string
	ID       int
	Username string
	Email    string
	// Ajoutez d'autres champs utilisateur selon vos besoins
}

func getUserDataByID(userID string) (UserData, error) {
	var userData UserData

	db, err := connectToDatabase()
	if err != nil {
		log.Fatal(err)
		Erreur(nil, nil ,http.StatusInternalServerError)
	}

	defer db.Close()

	// Exécuter la requête SQL pour récupérer les données d'utilisateur
	row := db.QueryRow("SELECT id_util, username, email FROM T_utilisateur WHERE id_util = ?", userID)

	err = row.Scan(&userData.ID, &userData.Username, &userData.Email)
	if err != nil {
		return userData, err
	}

	// Assigner le titre à UserData
	userData.Title = "Forum"

	return userData, nil
}