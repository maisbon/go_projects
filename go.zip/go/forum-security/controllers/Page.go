package controllers

import (
	"net/http"
	"text/template"
)

func renderPage(w http.ResponseWriter, r *http.Request, contentTemplate string) {
	if r.Method != "GET" && r.Method != "POST" {
		Erreur(w, r, http.StatusMethodNotAllowed)
		return
	}
	tmpl := template.Must(template.ParseFiles("templates/base.html", contentTemplate))
	if err := tmpl.ExecuteTemplate(w, "base.html", nil); err != nil {
		Erreur(w, r, http.StatusInternalServerError)
		return
	}
}

func Home(w http.ResponseWriter, r *http.Request) {
	renderPage(w, r, "templates/index.html")
}

func Registerpage(w http.ResponseWriter, r *http.Request) {
	renderPage(w, r, "templates/Auth/Signup.html")
}

func Loginpage(w http.ResponseWriter, r *http.Request) {
	renderPage(w, r, "templates/Auth/Login.html")
}

func Verifypage(w http.ResponseWriter, r *http.Request) {
	renderPage(w, r, "templates/Auth/verify.html")
}

func Updatepage(w http.ResponseWriter, r *http.Request) {
	renderPage(w, r, "templates/Auth/Update.html")
}