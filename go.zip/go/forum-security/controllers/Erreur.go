package controllers

import (
	"net/http"
	"text/template"
)

type ErrorMessage struct {
	Title   string
	Code    int
	Message string
}

func Erreur(w http.ResponseWriter, r *http.Request, statuscode int) {
	// Charger le modèle d'erreur correspondant
	var errorPage ErrorMessage

	switch statuscode {
	case http.StatusMethodNotAllowed:
		errorPage = ErrorMessage{Title: "Page d'erreur", Code: 405, Message: "Vous avez effectué une requête avec UNE METHODE NON AUTORISÉE"}
	case http.StatusInternalServerError:
		errorPage = ErrorMessage{Title: "Page d'erreur", Code: 500, Message: "Quelque chose s'est mal passé au niveau du serveur"}
	case http.StatusNotFound:
		errorPage = ErrorMessage{Title: "Page d'erreur", Code: 404, Message: "Désolé, la page que vous recherchez n'existe pas. Si vous pensez que quelque chose est cassé, signalez un problème."}
	}

	// Exécuter le modèle d'erreur avec les données d'erreur
	// Si ce n'est pas une requête POST, afficher la page de connexion
	tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Erreur/Erreur.html"))
	tmpl.ExecuteTemplate(w, "base.html", errorPage)

}