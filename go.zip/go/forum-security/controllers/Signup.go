package controllers

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"regexp"
	"strings"

	_ "github.com/mattn/go-sqlite3"
	"golang.org/x/crypto/bcrypt"
)

type AuErrorMessage struct {
	Title   string // Ajout du champ Title
	Message string
}

func isValidEmail(email string) bool {
	// Expression régulière pour vérifier le format d'une adresse e-mail
	emailRegex := `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`

	// Compiler l'expression régulière
	r := regexp.MustCompile(emailRegex)

	// Vérifier si la chaîne correspond à l'expression régulière
	return r.MatchString(email)
}

func isStrongPassword(password string) bool {
	// Vérifier si le mot de passe contient au moins 6 caractères
	if len(password) < 6 {
		return false
	}

	// Vérifier si le mot de passe contient au moins une lettre majuscule, une lettre minuscule, un chiffre et un caractère spécial
	hasUpperCase := false
	hasLowerCase := false
	hasDigit := false
	hasSpecialChar := false
	specialChars := "!@#$%^&*()_+{}[]|\\;:'\"<>,.?/~`"

	for _, char := range password {
		switch {
		case 'A' <= char && char <= 'Z':
			hasUpperCase = true
		case 'a' <= char && char <= 'z':
			hasLowerCase = true
		case '0' <= char && char <= '9':
			hasDigit = true
		case strings.ContainsRune(specialChars, char):
			hasSpecialChar = true
		}
	}

	return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar
}

func hashPassword(password string) (string, error) {
	// Hacher le mot de passe en utilisant bcrypt
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

func Signup(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		// Si ce n'est pas une requête POST, afficher la page de connexion
		tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/Signup.html"))
		tmpl.ExecuteTemplate(w, "base.html", nil)
		return
	}

	var message AuErrorMessage
	message.Title = "Page d'inscription"
	r.ParseForm()

	isAuthenticated := true

	username := r.Form.Get("username")
	if username == "" {
		message.Message = "Veuillez entrer un nom"
		isAuthenticated = false
	}

	email := r.Form.Get("email")
	if !isValidEmail(email) {
		message.Message = "L'adresse e-mail n'est pas valide."
		isAuthenticated = false
	}

	password := r.Form.Get("password")
	if password == "" {
		message.Message = "Veuillez entrer un mot de passe"
		isAuthenticated = false
	} else if !isStrongPassword(password) {
		message.Message = "Le mot de passe doit contenir au moins 6 caractères avec au moins une lettre majuscule, une lettre minuscule , un chiffre et un caractère spécial."
		isAuthenticated = false
	}

	if !isAuthenticated {
		// Afficher la page avec le message d'erreur
		tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/Signup.html"))
		tmpl.ExecuteTemplate(w, "base.html", message)
		return
	}

	hashedPassword, err := hashPassword(password)
	if err != nil {
		log.Fatal(err)
		Erreur(w, r, http.StatusInternalServerError)
	}

	db, err := connectToDatabase()
	if err != nil {
		log.Fatal(err)
		Erreur(w, r, http.StatusInternalServerError)
	}
	defer db.Close()

	// Vérifier si l'email est déjà utilisé
	var count int
	err = db.QueryRow("SELECT COUNT(*) FROM T_utilisateur WHERE email = ?", email).Scan(&count)
	if err != nil {
		log.Fatal(err)
		Erreur(w, r, http.StatusInternalServerError)
	}
	if count > 0 {
		message.Message = "L'adresse e-mail est déjà prise, essayez un autre e-mail"

		isAuthenticated = false

		return
	}

	// Vérifier si le nom d'utilisateur est déjà utilisé
	var usernameCount int
	err = db.QueryRow("SELECT COUNT(*) FROM T_utilisateur WHERE username = ?", username).Scan(&usernameCount)
	if err != nil {
		log.Fatal(err)
		Erreur(w, r, http.StatusInternalServerError)
	}
	if usernameCount > 0 {
		message.Message = "Le nom d'utilisateur est déjà pris, veuillez en choisir un autre"
		// Afficher la page avec le message d'erreur
		isAuthenticated = false
		return
	}

	// Exécuter la requête d'insertion avec le mot de passe haché et l'identifiant utilisateur
	_, err = db.Exec("INSERT INTO  T_utilisateur(username, email, mot_de_passe) VALUES (? , ?, ?)", username, email, hashedPassword)
	if err != nil {
		log.Fatal(err)
		Erreur(w, r, http.StatusInternalServerError)
	}

	
	// Redirection vers la page de connexion avec un message de réussite dans un pop-up
	successMessage := " bravo " + username + " Inscription réussie !"

	http.Redirect(w, r, fmt.Sprintf("/seconnecter?message=%s", successMessage), http.StatusFound)
}
