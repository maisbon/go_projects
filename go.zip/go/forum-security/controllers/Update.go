package controllers

import (
	"database/sql"
	"net/http"
	"text/template"

	"golang.org/x/crypto/bcrypt"
)

func Update(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		return
	}

	r.ParseForm()
	email := r.Form.Get("email")
	password1 := r.Form.Get("password1")
	password2 := r.Form.Get("password2")

	if password1 != password2 {
		// Si les mots de passe ne correspondent pas, afficher un message d'erreur
		errorMessage := ErrorMessage{
			Title:   "Erreur de réinitialisation du mot de passe",
			Message: "Les mots de passe ne sont pas identiques",
		}
		tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/Update.html"))
		if err := tmpl.ExecuteTemplate(w, "base.html", errorMessage); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		return
	}

	// Réinitialiser le mot de passe si les mots de passe correspondent
	err := resetPassword(email, password1)
	if err != nil {
		errorMessage := ErrorMessage{
			Title:   "Erreur de réinitialisation du mot de passe",
			Message: "Une erreur est survenue lors de la réinitialisation du mot de passe",
		}
		tmpl := template.Must(template.ParseFiles("templates/base.html", "templates/Auth/update.html"))
		if err := tmpl.ExecuteTemplate(w, "base.html", errorMessage); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		return
	}

	// Rediriger l'utilisateur vers la page de connexion après avoir réinitialisé le mot de passe avec succès
	http.Redirect(w, r, "/seconnecter", http.StatusFound)
}

func resetPassword(email, newPassword string) error {
	// Ouvrir la connexion à la base de données
	db, err := sql.Open("sqlite3", "Forum.db")
	if err != nil {
		return err
	}
	defer db.Close()

	// Hacher le nouveau mot de passe
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	// Réinitialiser le mot de passe dans la base de données pour l'utilisateur avec l'email donné
	_, err = db.Exec("UPDATE T_utilisateur SET mot_de_passe = ? WHERE email = ?", hashedPassword, email)
	if err != nil {
		return err
	}

	return nil
}