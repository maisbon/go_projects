package controllers

import "database/sql"

func connectToDatabase() (*sql.DB, error) {
	// Ouvrir la connexion à la base de données SQLite
	db, err := sql.Open("sqlite3", "Forum.db")
	if err != nil {
		return nil, err
	}
	return db, nil
}
