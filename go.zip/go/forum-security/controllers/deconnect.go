package controllers

import (
	"net/http"
	"time"
)

func Deconnect(w http.ResponseWriter) {
	// Créer un cookie vide pour remplacer le cookie de session existant
	expiredCookie := http.Cookie{
		Name:     "sessionID",
		Value:    "",
		Expires:  time.Unix(0, 0),
		HttpOnly: true,
	}

	// Définir le cookie expiré dans la réponse HTTP pour le supprimer
	http.SetCookie(w, &expiredCookie)

	// Créer un cookie vide pour le cookie utilisateur
	expiredUserCookie := http.Cookie{
		Name:     "userID",
		Value:    "",
		Expires:  time.Unix(0, 0),
		HttpOnly: true,
	}

	// Définir le cookie utilisateur expiré dans la réponse HTTP pour le supprimer
	http.SetCookie(w, &expiredUserCookie)
}

func Logout(w http.ResponseWriter, r *http.Request) {
	// Appeler la fonction pour supprimer les cookies de session
	Deconnect(w)

	// Rediriger l'utilisateur vers la page de connexion ou toute autre page appropriée
	http.Redirect(w, r, "/signin", http.StatusFound)
}
