
  function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
    } else {
      passwordInput.type = "password";
    }
  }

  function togglePasswordVisibility() {
    const passwordInput = document.getElementById("password");
    const passStatus = document.querySelector(".password-toggle");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        passStatus.classList.replace("fa-eye-slash", "fa-eye");
    } else {
        passwordInput.type = "password";
        passStatus.classList.replace("fa-eye", "fa-eye-slash");
    }
}

// Récupérer le message de réussite de l'URL
const urlParams = new URLSearchParams(window.location.search);
const successMessage = urlParams.get('message');

// Vérifier si un message de réussite est présent
if (successMessage) {
    // Afficher le pop-up avec le message de réussite
    alert(successMessage);
}


