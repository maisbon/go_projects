package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
)

func main() {
	if len(os.Args) == 1 {
		os.Exit(0)
	}
	if len(os.Args) != 2 {
		fmt.Println("Erreur")
		return
	}

	// Sépare les nombres fournis en entrée et initialise deux piles (aStack et bStack)
	userInput := strings.Split(os.Args[1], " ")
	var aStack []int
	var bStack []int

	// Ajoute les nombres à la pile aStack
	err := AppendNumbers(userInput, &aStack)
	if err {
		return
	}

	// Liste de toutes les instructions possibles
	var allInstructions []string = []string{"pa", "pb", "sa", "sb", "ss", "ra", "rb", "rr", "rra", "rrb", "rrr"}
	var instructionsToUse []string

	// Obtenir les instructions à partir de l'entrée standard
	errorDetected := GetInstructions(allInstructions, &instructionsToUse)
	if errorDetected {
		return
	}

	// Parcourt les instructions et exécute les actions correspondantes
	for i := 0; i < len(instructionsToUse); i++ {
		if instructionsToUse[i] == "pa" {
			PushTop(&bStack, &aStack)
		} else if instructionsToUse[i] == "pb" {
			PushTop(&aStack, &bStack)
		} else if instructionsToUse[i] == "sa" {
			Swap(&aStack)
		} else if instructionsToUse[i] == "sb" {
			Swap(&bStack)
		} else if instructionsToUse[i] == "ss" {
			SwapBoth(&aStack, &bStack)
		} else if instructionsToUse[i] == "ra" {
			Rotate(&aStack)
		} else if instructionsToUse[i] == "rb" {
			Rotate(&bStack)
		} else if instructionsToUse[i] == "rr" {
			RotateBoth(&aStack, &bStack)
		} else if instructionsToUse[i] == "rra" {
			ReverseRotate(&aStack)
		} else if instructionsToUse[i] == "rrb" {
			ReverseRotate(&bStack)
		} else {
			ReverseRotateBoth(&aStack, &bStack)
		}
	}

	// Vérifie si aStack est triée et si bStack est vide, puis imprime "OK" ou "KO" en conséquence
	if sort.IntsAreSorted(aStack) && len(bStack) == 0 {
		fmt.Println("OK")
	} else {
		fmt.Println("KO")
	}
}

// Lit les instructions sur l'entrée standard et les sauvegarde. Si une instruction n'existe pas - retourne vrai
func GetInstructions(allInstructions []string, instructionsToUse *[]string) bool {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		for i, k := range allInstructions {
			if scanner.Text() == "stop" {
				return false
			}

			if scanner.Text() == "" {
				continue
			}

			if k == scanner.Text() {
				*instructionsToUse = append(*instructionsToUse, scanner.Text())
				break
			}

			if i == len(allInstructions)-1 {
				fmt.Println("Erreur")
				return true
			}
		}
	}
	return false
}

// Ajoute tous les nombres à la pile aStack
func AppendNumbers(userInput []string, aStack *[]int) bool {
	for i := 0; i < len(userInput); i++ {
		numToAppend, err := strconv.Atoi(userInput[i])
		if err != nil {
			fmt.Println("Erreur")
			return true
		}

		// Vérifie les doublons
		if i != 0 {
			for k := 0; k < len(*aStack); k++ {
				if (*aStack)[k] == numToAppend {
					fmt.Println("Erreur")
					return true
				}
			}
		}

		(*aStack) = append((*aStack), numToAppend)
	}
	return false
}

// Pousse le premier élément en haut d'une pile dans une autre pile (pa, pb)
func PushTop(exStack *[]int, impStack *[]int) {
	if len(*exStack) == 0 {
		// fmt.Println("Pas assez d'éléments")
		return
	}
	tempVar := (*exStack)[0]
	*exStack = append((*exStack)[:0], (*exStack)[0+1:]...)

	if len(*impStack) == 0 {
		*impStack = append(*impStack, tempVar)
		return
	}

	*impStack = append((*impStack)[:0+1], (*impStack)[0:]...)
	(*impStack)[0] = tempVar
}

// Échange les deux premiers éléments de la pile (sb, sa)
func Swap(stack *[]int) {
	if len(*stack) < 2 {
		// fmt.Println("Pas assez d'éléments")
		return
	}

	tempVar := (*stack)[0]
	(*stack)[0] = (*stack)[1]
	(*stack)[1] = tempVar
}

// Décale tous les éléments d'une pile vers le haut de 1 (ra, rb)
func Rotate(stack *[]int) {
	if len(*stack) < 2 {
		return
	}

	newStack := make([]int, len(*stack))

	newStack[len(*stack)-1] = (*stack)[0]

	for i := 1; i < len(*stack); i++ {
		newStack[i-1] = (*stack)[i]
	}

	*stack = newStack
}

// Décale tous les éléments d'une pile vers le bas de 1 (rra, rrb)
func ReverseRotate(stack *[]int) {
	if len(*stack) < 2 {
		return
	}

	newStack := make([]int, len(*stack))

	newStack[0] = (*stack)[len(*stack)-1]

	for i := 1; i < len(*stack); i++ {
		newStack[i] = (*stack)[i-1]
	}

	*stack = newStack
}

// Exécute la fonction Swap pour les deux piles (ss)
func SwapBoth(A_StackTable *[]int, B_StackTable *[]int) {
	Swap(A_StackTable)
	Swap(B_StackTable)
}

// Exécute la fonction Rotate pour les deux piles (rr)
func RotateBoth(A_StackTable *[]int, B_StackTable *[]int) {
	Rotate(A_StackTable)
	Rotate(B_StackTable)
}

// Exécute la fonction ReverseRotate pour les deux piles (rrr)
func ReverseRotateBoth(A_StackTable *[]int, B_StackTable *[]int) {
	ReverseRotate(A_StackTable)
	ReverseRotate(B_StackTable)
}
