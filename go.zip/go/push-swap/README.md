# AOBRO PUSHSWAP

Ce programme est une implémentation de l'algorithme de tri de pile, également connu sous le nom de Tri par Piles (Stack Sorter). L'algorithme de tri de pile est un algorithme de tri qui utilise deux piles pour trier un ensemble donné d'éléments. Le programme prend en entrée une liste de nombres à trier et une série d'instructions pour effectuer le tri en utilisant les opérations de poussée, d'échange et de déplacement des éléments dans les piles.

## Utilisation

Pour exécuter le programme, suivez les étapes ci-dessous :


1. Exécutez le programme en fournissant une liste de nombres séparés par des espaces et une série d'instructions pour effectuer le tri. Par exemple :
   ```
   ./push-swap.

   ```
   


2. Le programme effectuera le tri en fonction des instructions fournies et affichera "OK" si la première pile est triée et que la deuxième pile est vide, ou "KO" sinon.

## Structure du Code

Le code est organisé en plusieurs fonctions pour effectuer différentes opérations sur les piles, telles que l'ajout de nombres à la pile, la manipulation des éléments dans les piles, la vérification des instructions fournies et l'exécution des opérations de tri. Chaque fonction a un rôle spécifique et contribue au processus de tri des piles.
