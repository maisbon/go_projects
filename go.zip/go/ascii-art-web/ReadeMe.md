# ASCII Art Generator

## Description

Ce projet est un serveur web qui génère de l'art ASCII à partir d'un texte et d'une bannière. Il permet aux utilisateurs de saisir du texte et de choisir une bannière, puis il génère l'art ASCII correspondant et l'affiche sur une page web.

## Auteurs

- kmakissi
- rekouakou
- malarissa

## Installation

1. Clonez le dépôt Git sur votre machine locale.
2. Installez Go sur votre machine si ce n'est pas déjà fait.
3. Ouvrez un terminal et naviguez vers le répertoire du projet.
4. Exécutez la commande `go run main.go` pour démarrer le serveur.

## Utilisation

1. Ouvrez un navigateur web et accédez à `http://localhost:8080`
2. Vous verrez un formulaire où vous pouvez saisir du texte et choisir une bannière.
3. Cliquez sur le bouton "Générer l'art ASCII" pour générer l'art ASCII correspondant.

## Détails d'implémentation

L'algorithme de génération de l'art ASCII fonctionne en suivant les étapes suivantes :

1. Lire le texte à convertir en art ASCII.
2. Pour chaque caractère du texte, rechercher la représentation ASCII correspondante dans le fichier de représentations ASCII.
3. Si la représentation ASCII existe, l'ajouter à l'art ASCII généré.
4. Si la représentation ASCII n'existe pas, utiliser un caractère par défaut (par exemple, un espace).
5. Répéter les étapes 2 à 4 pour tous les caractères du texte.




