// Package main contient le serveur web pour générer de l'art ASCII à partir d'un texte et d'une bannière.
package main

import (
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"strings"
)

func getASCIIOfLetters(text string, alpha map[rune][]string) [][]string {
	// Trouver le correspondant ASCII de chaque lettre du texte et le stocker
	// 'text' est le texte à afficher
	// 'alpha' est l'aphabet (notre dictionnaire ou encore Map) qui contient les correspondances clé-valeur de chaque lettre de l'alphabet
	// Le résulta final est une liste de liste de string car le code ASCII art d'une lettre est une liste de String où chaque élément représente chaque ligne ASCII de la lettre
	var result [][]string
	for _, letter := range text {
		result = append(result, alpha[letter])

	}
	return result
}

func joinASCIIs(asciis [][]string, nbLines int) []string {
	// Joindre les lignes de chaque lettre en ASCII ensembles (en respectant les indices)
	// 'asciis' est la liste contenant les correspondants ASCII de chaque lettre du texte
	// 'nbLines' est le nombre de ligne sur lesquels tient chaque lettre ASCII (il est constant pour tout les lettres)
	var result []string
	for line := 0; line < nbLines; line++ {
		var res string
		for _, ascii := range asciis {

			if len(ascii) != 0 {

				res = res + ascii[line]
			}

		}

		result = append(result, res)
	}
	return result
}

func translate(text string, alpha map[rune][]string) []string {
	// Le pipeline de notre code. La fonction d'entrée qui sera appelée dans le main()
	// Il appelle chaque fonction dans l'ordre voulu pour atteindre le résultat
	// 'text' est le texte à afficher
	// 'alpha' est notre alphabet ascii (notre dictionnaire)
	asciis := getASCIIOfLetters(text, alpha) // obtenir le code ascii de chaque lettre du texte
	ascii_lines := joinASCIIs(asciis, 8)     // joindre les lignes des codes ascii ensembles
	return ascii_lines                       // afficher le résultat
}

//bibliotheque
func getAlphabet(name string, nblines int) map[rune][]string {
	//asciiChars est un tableau qui contient touts les caractère du tableau ascii
	var asciiChars = []rune{' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E',
		'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[',
		'\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
		'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~'}
	file := name + ".txt"
	//fmt.Println("fffff:", file)
	alphabet := make(map[rune][]string)

	content, err := ioutil.ReadFile(file)
	if err != nil {
		fmt.Println("Erreur lors de la lecture du fichier :", err)
		return nil
	}
	//creer un tableau avec chaque lettre du fichier
	lines := strings.Split(string(content), "\n")

	//nombre de lignes du tableau et represente aussi le nombre de ligne dans le fichier standart
	nbTabLines := len(lines)
	var letter []string
	var nbAddition int

	for idx := 0; idx < nbTabLines; idx++ {
		if idx%nblines == 0 {
			if len(letter) != 0 {
				alphabet[asciiChars[nbAddition]] = letter
				// '!':{  ___}
				// '#':{  ___}
				letter = nil
				nbAddition++
			}
		} else {
			line := lines[idx]
			letter = append(letter, strings.Replace(line, "\\n", "", -1)[:len(line)-1])
		}
	}

	return alphabet
}

// FormData représente les données du formulaire.
type FormData struct {
	Text   string
	Banner string
	Result string
}

// homeHandler est le gestionnaire pour l'endpoint GET /.
// Il charge le template HTML et renvoie la page principale avec le formulaire.
func homeHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" && r.URL.Path == "/" {
		// Charge le template HTML
		tmpl, err := template.ParseFiles("templates/home.html")
		if err != nil {
			http.Error(w, "", http.StatusInternalServerError)
			return
		}

		// Renvoie la page principale avec le formulaire
		tmpl.Execute(w, nil)
	} else {
		http.NotFound(w, r)
	}

}

// asciiArtHandler est le gestionnaire pour l'endpoint POST /ascii-art.
// Il récupère les données du formulaire, génère l'art ASCII en utilisant les données du formulaire,
// charge le template HTML, et renvoie la page de résultat avec l'art ASCII généré.

func asciiArtHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method == "POST" && r.URL.Path == "/ascii-art" {

		// Récupère les données du formulaire
		err := r.ParseForm()

		// Récupère les valeurs du formulaire
		text := r.FormValue("text")
		banner := r.FormValue("banner")
		// Génère l'art ASCII en utilisant les données du formulaire
		lines := strings.SplitN(text, "\n", 2)
		var resultat []string
		name := banner
		nblines := 9
		alphabet := getAlphabet(name, nblines)

		for _, line := range lines {
			result := translate(line, alphabet)
			if err != nil {
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
				return
			}
			resultat = append(resultat, strings.Join(result, "\n"))

		}

		// Charge le template HTML
		tmpl, err := template.ParseFiles("templates/result.html")
		if err != nil {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}
		// Renvoie la page de résultat avec l'art ASCII généré
		data := FormData{Text: text, Banner: banner, Result: strings.Join(resultat, "\n")}
		tmpl.Execute(w, data)
	} else {
		w.WriteHeader(http.StatusBadRequest)
	}
}

// main est la fonction principale qui configure les gestionnaires pour les endpoints et démarre le serveur.
func main() {
	// Configuration des gestionnaires pour les endpoints
	http.HandleFunc("/", homeHandler)
	http.HandleFunc("/ascii-art", asciiArtHandler)
	// Démarrage du serveur sur le port 8080
	port := 8080
	fmt.Printf("Serveur fonctionne sur :%d\n", port)
	http.ListenAndServe(fmt.Sprintf(":%d", port), nil)

}
