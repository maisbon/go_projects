package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {

	// Vérifier le nombre d'arguments
	if len(os.Args) < 2 || len(os.Args) > 3 {
		fmt.Println("Usage: go run . [STRING] [BANNER]")
		fmt.Println("EX: go run . something standard")
		return
	}
	// récupération du nom du fichier banière et son ouverture
	osfichier := os.Args[2] + ".txt"
	fichier, err := os.Open(osfichier)
	if err != nil {
		fmt.Println(err)
		return
	}

	defer fichier.Close()
	// lecture du contenue et transfert du contenue dans une slice
	var banniere []string
	scanner := bufio.NewScanner(fichier)
	for scanner.Scan() {
		banniere = append(banniere, scanner.Text())
	}
	// écupération du texte à afficher via la ligne de commande
	argu := os.Args[1:]
	argcoupe := argu[:len(argu)-1]
	argutilise := strings.Join(argcoupe, " ")

	texte := AsciiArt(argutilise, banniere)

	fmt.Println(texte)
}

// creation du ascii art
func AsciiArt(argutilise string, contenutxt []string) string {
	var builder strings.Builder

	lignetxt := strings.Split(argutilise, "\\n")

	for i, lettre := range lignetxt {

		if len(lettre) == 0 && i == len(lignetxt)-1 {
			continue
		}

		if len(lettre) == 0 {
			builder.WriteString("\n")
			continue
		}

		for j := 0; j < 8; j++ {

			for _, char := range lettre {

				pos := 1 + (int(char)-32)*9 + j

				builder.WriteString(contenutxt[pos])
			}

			if !(i == len(lignetxt)-1 && j == 7) {
				builder.WriteString("\n")
			}
		}
	}

	return builder.String()
}
