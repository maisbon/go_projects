package main

import (
	"fmt"
	"forum/controllers"
	"forum/initializers"
	"log"
	"net/http"
)

func main() {
	_, err := initializers.InitDB()
	if err != nil {
		panic(err)
	}
	// Définir les gestionnaire
	http.Handle("/resources/", http.StripPrefix("/resources/", http.FileServer(http.Dir("resources"))))
	// Définir les autres routes
	http.HandleFunc("/", controllers.IndexHandler)
	http.HandleFunc("/form", controllers.FormHandler)
	http.HandleFunc("/register", controllers.RegisterUserHandler)
	http.HandleFunc("/connexion", controllers.ConnexionUserHandler)
	http.HandleFunc("/forum/acceuil", controllers.ForumAcceuilHandler)
	http.HandleFunc("/deconnexion", controllers.DeconnexionHandler)
	http.HandleFunc("/publier", controllers.PublicationHandler)
	http.HandleFunc("/checkSession", controllers.CheckSession)
	http.HandleFunc("/getcommentaires", controllers.CommentairesHandler)
	http.HandleFunc("/commenter", controllers.CommentairesHandler)
	// Routes pour les likes et dislikes
	http.HandleFunc("/like-dislike-post", controllers.LikeDislikePostHandler)
	http.HandleFunc("/like-dislike-comment", controllers.LikeDislikeCommentHandler)
	// Démarrer le serveur HTTP sur le port 8080
	fmt.Println("Server running on port 8081")
	log.Fatal(http.ListenAndServe(":8081", nil))
}
