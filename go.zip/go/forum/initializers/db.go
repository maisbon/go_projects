package initializers

import (
	"database/sql"

	_ "github.com/mattn/go-sqlite3"
)

func InitDB() (*sql.DB, error) {
	// Ouvrir la connexion à la base de données
	db, err := sql.Open("sqlite3", "forum.db")
	if err != nil {
		return nil, err
	}

	// Créer la table pour stocker les informations des utilisateurs
	_, err = db.Exec(`
			CREATE TABLE IF NOT EXISTS utilisateur (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				nom TEXT NOT NULL,
				prenom TEXT NOT NULL,
				photo BLOB,
				username TEXT NOT NULL,
				mot_de_passe TEXT NOT NULL,
				email TEXT NOT NULL
			);
			
			CREATE TABLE IF NOT EXISTS categories (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				name VARCHAR(255) UNIQUE NOT NULL
			);

			CREATE TABLE IF NOT EXISTS posts (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				user_id INT NOT NULL,
				categorie_id INT NOT NULL,
				title VARCHAR(255) NOT NULL,
				content TEXT NOT NULL,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				FOREIGN KEY (user_id) REFERENCES users(id),
				FOREIGN KEY (categorie_id) REFERENCES categories(id)
			);

			CREATE TABLE IF NOT EXISTS comments (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				post_id INT NOT NULL,
				user_id INT,
				content TEXT NOT NULL,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				FOREIGN KEY (post_id) REFERENCES posts(id),
				FOREIGN KEY (user_id) REFERENCES users(id)
			);

			
			CREATE TABLE IF NOT EXISTS post_categories (
				post_id INT NOT NULL,
				category_id INT NOT NULL,
				FOREIGN KEY (post_id) REFERENCES posts(id),
				FOREIGN KEY (category_id) REFERENCES categories(id)
			);

			  CREATE TABLE IF NOT EXISTS post_likes (
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					post_id INT,
					user_id INT,
					type TEXT CHECK (type IN ('liked', 'dislike')),
					created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
					FOREIGN KEY (post_id) REFERENCES posts(id),
					FOREIGN KEY (user_id) REFERENCES utilisateur(id)
					UNIQUE (post_id, user_id)
				);

			CREATE TABLE IF NOT EXISTS comment_likes (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				comment_id INT,
				user_id INT,
				type TEXT CHECK (type IN ('liked', 'dislike')),
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				FOREIGN KEY (comment_id) REFERENCES comments(id),
				FOREIGN KEY (user_id) REFERENCES utilisateur(id)
				UNIQUE (comment_id, user_id)
			);

			
			
    `)
	if err != nil {
		return nil, err
	}

	// Définir les catégories à insérer
	categories := []string{"frontend", "backend", "design"}
	// Préparer l'instruction d'insertion
	stmt, err := db.Prepare("INSERT OR IGNORE INTO categories (name) VALUES (?)")
	if err != nil {
		return nil, err
	}
	defer stmt.Close()

	// Parcourir le tableau des catégories et les insérer
	for _, category := range categories {
		_, err = stmt.Exec(category)
		if err != nil {
			return nil, err
		}
	}

	return db, nil
}

func GetDb() (db *sql.DB, err error) {
	db, err = sql.Open("sqlite3", "./forum.db")
	if err != nil {
		return nil, err
	}
	return
}
