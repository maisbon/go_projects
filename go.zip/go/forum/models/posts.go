package models

import (
	"database/sql"
	"fmt"
	"forum/initializers"
	"time"
)

// Post représente une publication créée par un utilisateur
type Post struct {
	ID           int       `json:"id"`
	User         int       `json:"user"`
	Title        string    `json:"title"`
	Content      string    `json:"content"`
	CreatedAt    time.Time `json:"created_at"`
	Categorie    int       `json:"categorie"`
	LikeCount    int       `json:"like_count"`
	DislikeCount int       `json:"dislike_count"`
	CountComment int       `json:"count_comment"`
	Liked        bool      `json:"bool"`
}

type DataPost struct {
	ID           int       `json:"id"`
	User         string    `json:"user"`
	Title        string    `json:"title"`
	Content      string    `json:"content"`
	CreatedAt    time.Time `json:"created_at"`
	Categorie    int       `json:"categorie"`
	LikeCount    int       `json:"like_count"`
	DislikeCount int       `json:"dislike_count"`
	CountComment int       `json:"count_comment"`
	Liked        bool      `json:"bool"`
}

func IsPostLikedByUser(postID int) bool {
	db, err := initializers.GetDb()
	if err != nil {
		return false
	}

	var count int
	err = db.QueryRow("SELECT COUNT(*) FROM post_likes WHERE post_id = ?  AND type = 'liked'", postID).Scan(&count)
	if err != nil {
		return false
	}

	return count > 0
}

func GetAllPost() ([]DataPost, error) {
	db, errs := initializers.GetDb()
	if errs != nil {
		return nil, errs
	}

	var publication []DataPost
	query := `
        SELECT posts.id, posts.title, posts.content, utilisateur.username, posts.categorie_id , posts.created_at
        FROM posts
        JOIN utilisateur ON posts.user_id = utilisateur.id
    `
	rows, err := db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	// Loop through rows, using Scan to assign column data to struct fields.

	for rows.Next() {
		var alb DataPost
		if err := rows.Scan(&alb.ID, &alb.Title, &alb.Content, &alb.User, &alb.Categorie, &alb.CreatedAt); err != nil {
			return nil, err
		}
		alb.LikeCount = GetPostLikesCount(alb.ID, "liked")
		alb.DislikeCount = GetPostLikesCount(alb.ID, "dislike")
		alb.CountComment, errs = GetCountComment(alb.ID)
		alb.Liked = IsPostLikedByUser(alb.ID)
		if errs != nil {
			fmt.Println("error count comment", errs)
			return nil, err
		}
		//fmt.Println("alboooooooooooooooo", alb)
		publication = append(publication, alb)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return publication, nil
}

func CreatePost(post Post) error {
	db, errs := initializers.GetDb()
	if errs != nil {
		return errs
	}
	//fmt.Println(db)
	// Préparer la requête d'insertion
	stmt, err := db.Prepare(`
			INSERT INTO posts (user_id,categorie_id, title, content ) 
			VALUES ( ?, ?, ?, ?)
    `)
	if err != nil {
		return err
	}
	defer stmt.Close()

	// Exécuter la requête d'insertion avec les valeurs de l'utilisateur
	_, err = stmt.Exec(post.User, post.Categorie, post.Title, post.Content)
	if err != nil {
		return err
	}
	fmt.Println("Utilisateur inséré avec succès")
	return nil
}

func GetOnePost(id int) (*DataPost, error) {
	db, errs := initializers.GetDb()
	if errs != nil {
		return nil, errs
	}

	var post DataPost
	query := `
	SELECT posts.id, posts.title, posts.content, utilisateur.username, posts.categorie_id, posts.created_at
	FROM posts
	JOIN utilisateur ON posts.user_id = utilisateur.id
	WHERE posts.id = ?
`

	row := db.QueryRow(query, id)

	err := row.Scan(&post.ID, &post.Title, &post.Content, &post.User, &post.Categorie, &post.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("no post found with id %d", id)
		}
		return nil, err
	}
	post.LikeCount = GetPostLikesCount(id, "liked")
	post.DislikeCount = GetPostLikesCount(id, "dislike")
	return &post, nil
}
