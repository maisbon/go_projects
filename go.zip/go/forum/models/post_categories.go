package models

import (
	"fmt"
	"forum/initializers"
)

// PostCategory représente la relation entre les posts et les catégories
type PostCategory struct {
	PostID     int `json:"post_id"`
	CategoryID int `json:"category_id"`
}

func CreatePostCategory(post Category) error {
	db, errs := initializers.GetDb()
	if errs != nil {
		return errs
	}
	fmt.Println(db)
	return nil
}
