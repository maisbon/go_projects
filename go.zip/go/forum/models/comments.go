package models

import (
	"fmt"
	"forum/initializers"
	"log"
	"time"
)

type Comment struct {
	ID           int       `json:"id"`
	PostID       int       `json:"post_id"`
	UserID       int       `json:"user_id"`
	Content      string    `json:"content"`
	CreatedAt    time.Time `json:"created_at"`
	LikeCount    int       `json:"like_count"`
	DislikeCount int       `json:"dislike_count"`
	Liked        bool      `json:"bool"`
}

type DataComment struct {
	ID           int       `json:"id"`
	PostID       int       `json:"post_id"`
	UserID       string    `json:"user_id"`
	Content      string    `json:"content"`
	CreatedAt    time.Time `json:"created_at"`
	LikeCount    int       `json:"like_count"`
	DislikeCount int       `json:"dislike_count"`
	Liked        bool      `json:"bool"`
}

// fonction pour creer un commentaire
func CreateComment(comments Comment) error {
	db, errs := initializers.GetDb()
	if errs != nil {
		return errs
	}
	fmt.Println("comment---create:", comments.PostID)

	stmt, err := db.Prepare(`
			INSERT INTO comments (user_id, post_id, content, created_at ) 
			VALUES ( ?, ?, ?,?)
    `)
	if err != nil {
		return err
	}
	defer stmt.Close()

	// Exécuter la requête d'insertion avec les valeurs de l'utilisateur
	_, err = stmt.Exec(comments.UserID, comments.PostID, comments.Content, comments.CreatedAt)
	if err != nil {
		return err
	}
	fmt.Println("Utilisateur inséré avec succès")
	return nil
}

// je recupere la liste des commentaires en fonction de l'id dune publication
func GetAllComment(idPost int) ([]DataComment, error) {
	db, errs := initializers.GetDb()
	if errs != nil {
		return nil, errs
	}
	//fmt.Println("idPost", idPost)
	var commentaires []DataComment

	query := `  SELECT comments.id, comments.content,  utilisateur.username, comments.post_id, comments.created_at
        FROM comments
        JOIN utilisateur ON comments.user_id = utilisateur.id
        WHERE comments.post_id = ?`
	rows, err := db.Query(query, idPost)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var commentaire DataComment
		err := rows.Scan(&commentaire.ID, &commentaire.Content, &commentaire.UserID, &commentaire.PostID, &commentaire.CreatedAt)
		if err != nil {
			return nil, err
		}
		commentaire.LikeCount = GetCommentLikesCount(commentaire.ID, "liked")
		commentaire.DislikeCount = GetCommentLikesCount(commentaire.ID, "dislike")
		fmt.Println("alboooooooocomment", commentaire)
		commentaires = append(commentaires, commentaire)
	}

	// Vérification des erreurs potentiellement survenues lors de l'itération
	if err = rows.Err(); err != nil {
		return nil, err
	}

	// Si aucun commentaire n'est trouvé, on retourne un tableau vide
	if len(commentaires) == 0 {
		fmt.Println("Aucun commentaire trouvé pour ce post.")
	}

	fmt.Println("Liste des commentaires", commentaires)
	return commentaires, nil

}

// le nombre de commentaire d'une publication
func GetCountComment(idPost int) (int, error) {
	// Initialiser la connexion à la base de données
	db, err := initializers.GetDb()
	if err != nil {
		log.Println("Error initializing database:", err)
		return 0, err
	}

	// Définir la requête SQL pour compter les commentaires pour un post donné
	query := `
        SELECT COUNT(*) 
        FROM comments 
        WHERE post_id = ?
    `

	// Exécuter la requête SQL
	var count int
	err = db.QueryRow(query, idPost).Scan(&count)
	if err != nil {
		log.Println("Error executing query:", err)
		return 0, err
	}

	// Retourner le nombre de commentaires
	return count, nil
}

// GetCommentLikesCount retourne le nombre de likes ou dislikes pour un commentaire
