package models

import (
	"fmt"
	"forum/initializers"
	"time"
)

type LikeDislike struct {
	ID        int       `json:"id"`
	UserID    int       `json:"user_id"`
	TargetID  int       `json:"target_id"`
	Type      string    `json:"type"`
	CreatedAt time.Time `json:"created_at"`
}

/********************************PUBLICATIONS*****************************************/
// HandlePostLikeDislike gère les likes et dislikes des posts
func HandlePostLikeDislike(postID, userID int, likeType string) error {
	db, err := initializers.GetDb()
	if err != nil {
		return err
	}

	// Tentez d'insérer une nouvelle ligne
	stmt, err := db.Prepare(`
        INSERT INTO post_likes (post_id, user_id, type)
        VALUES (?, ?, ?)
        ON CONFLICT(post_id, user_id) DO UPDATE SET type=excluded.type
    `)
	if err != nil {
		fmt.Println("Error preparing statement:", err)
		return err
	}
	defer stmt.Close()

	_, err = stmt.Exec(postID, userID, likeType)
	if err != nil {
		fmt.Println("Error executing statement:", err)
		return err
	}

	fmt.Printf("Like/Dislike successfully inserted or updated for post_id: %d, user_id: %d\n", postID, userID)
	return nil
}

// GetPostLikesCount retourne le nombre de likes ou dislikes pour un post
func GetPostLikesCount(postID int, likeType string) int {
	db, err := initializers.GetDb()
	if err != nil {
		return 0
	}

	var count int
	query := `SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND type = ?`
	row := db.QueryRow(query, postID, likeType)
	row.Scan(&count)

	return count
}

/***********************COMMENTAIRES**************************************************/
// HandleCommentLikeDislike gère les likes et dislikes des commentaires
func HandleCommentLikeDislike(commentID, userID int, likeType string) error {
	db, err := initializers.GetDb()
	if err != nil {
		return err
	}

	// Tentez d'insérer une nouvelle ligne
	stmt, err := db.Prepare(`
        INSERT INTO comment_likes (comment_id, user_id, type)
        VALUES (?, ?, ?)
        ON CONFLICT(comment_id, user_id) DO UPDATE SET type=excluded.type
    `)
	if err != nil {
		fmt.Println("Error preparing statement:", err)
		return err
	}
	defer stmt.Close()

	_, err = stmt.Exec(commentID, userID, likeType)
	if err != nil {
		fmt.Println("Error executing statement:", err)
		return err
	}

	fmt.Printf("Like/Dislike successfully inserted or updated for comment_like: %d, user_id: %d\n", commentID, userID)
	return nil
}

// GetCommentLikesCount retourne le nombre de likes ou dislikes pour un commentaire
func GetCommentLikesCount(commentID int, likeType string) int {
	db, err := initializers.GetDb()
	if err != nil {
		return 0
	}
	var count int
	query := `SELECT COUNT(*) FROM comment_likes WHERE comment_id = ? AND type = ?`
	row := db.QueryRow(query, commentID, likeType)
	row.Scan(&count)

	return count
}
