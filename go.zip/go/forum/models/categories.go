package models

import (
	"fmt"
	"forum/initializers"
)

type Category struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// Category représente une catégorie associée à des publications
func CreateCategory(post Category) error {
	db, errs := initializers.GetDb()
	if errs != nil {
		return errs
	}
	fmt.Println(db)
	return nil
}

// requette pour recuperer tous les utilisateurs
func FindAllCategorie() ([]Category, error) {
	// Préparer la requête d'insertion
	db, errs := initializers.GetDb()
	if errs != nil {
		return nil, errs
	}

	rows, err := db.Query("SELECT id, name FROM categories")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var categories []Category
	for rows.Next() {
		var category Category
		if err := rows.Scan(&category.ID, &category.Name); err != nil {
			return nil, err
		}
		categories = append(categories, category)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return categories, nil
}

func GetAllCategories() ([]Category, error) {
	db, err := initializers.GetDb()
	if err != nil {
		return nil, err
	}

	rows, err := db.Query("SELECT id, name FROM categories")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var categories []Category
	for rows.Next() {
		var cat Category
		if err := rows.Scan(&cat.ID, &cat.Name); err != nil {
			return nil, err
		}
		categories = append(categories, cat)
	}

	return categories, nil
}
