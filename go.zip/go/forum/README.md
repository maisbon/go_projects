# docker image build -f Dockerfile -t <digi_forum> .                   

# docker container run -p 8081:8081 --detach --name <app_digiforum> <digi_forum>