package controllers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"forum/models"
	"html/template"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gorilla/sessions"
	"golang.org/x/crypto/bcrypt"
)

var store = sessions.NewCookieStore([]byte("cAR35t342MvhTt"))

type FormData struct {
	Categorie   []models.Category
	Publication []models.DataPost
	Username    string
}
type FormDataComment struct {
	Commentaires []models.DataComment
	Publication  *models.DataPost
}

func IndexHandler(w http.ResponseWriter, r *http.Request) {
	tpl := template.Must(template.ParseFiles("views/acceuil.html"))
	categories, err := models.FindAllCategorie()
	if err != nil {
		log.Fatal(err)
	}
	dataPost, err := models.GetAllPost()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	//fmt.Println("dataPost", dataPost)

	data := FormData{
		Categorie:   categories,
		Publication: dataPost,
	}
	//fmt.Println("categories", data)
	if err := tpl.Execute(w, data); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func FormHandler(w http.ResponseWriter, r *http.Request) {
	tpl := template.Must(template.ParseFiles("views/form.html"))
	if err := tpl.Execute(w, nil); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func ForumAcceuilHandler(w http.ResponseWriter, r *http.Request) {

	session, err := store.Get(r, "digiforum")
	if err != nil {
		http.Error(w, "Erreur de session", http.StatusInternalServerError)
		return
	}

	// Vérifier si l'utilisateur est authentifié
	userID, ok := session.Values["username"].(string)
	if !ok {
		// L'utilisateur n'est pas authentifié, rediriger vers la page de connexion
		http.Redirect(w, r, "/form", http.StatusFound)
		return
	}
	fmt.Println(userID)

	tpl := template.Must(template.ParseFiles("views/acceuil.html"))
	if err := tpl.Execute(w, nil); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

// Inscription de l'utilisateur
func RegisterUserHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		// Lire les données JSON de la requête
		var user models.User
		err := json.NewDecoder(r.Body).Decode(&user)

		if err != nil {
			http.Error(w, "Erreur lors de la lecture des données JSON", http.StatusBadRequest)
			return
		}
		var email = user.Email
		// Vérifier si l'email ou le nom d'utilisateur est déjà présent dans la base de données
		if userExists(email, "email") || userExists(user.Username, "username") {
			fmt.Println("Email ou nom d'utilisateur déjà utilisé")
			http.Error(w, "Email ou nom d'utilisateur déjà utilisé", http.StatusBadRequest)
			return
		}

		// Insérer l'utilisateur dans la base de données
		err = models.InsertUser(user)
		if err != nil {
			http.Error(w, "Erreur lors de l'insertion de l'utilisateur dans la base de données", http.StatusInternalServerError)
			return
		}

		// Créer un objet réponse contenant des données JSON
		response := struct {
			Message string `json:"message"`
		}{
			Message: "Inscription réussie pour l'utilisateur: " + user.Username,
		}

		// Convertir la réponse en JSON
		jsonResponse, err := json.Marshal(response)
		if err != nil {
			http.Error(w, "Erreur lors de la conversion de la réponse en JSON", http.StatusInternalServerError)
			return
		}

		// Définir le type de contenu de la réponse comme JSON
		w.Header().Set("Content-Type", "application/json")
		// Répondre avec un code de statut 200 et les données JSON
		w.WriteHeader(http.StatusOK)
		w.Write(jsonResponse)
	}
}

// Connexion
func ConnexionUserHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("connexionnnnn")
	if r.Method == "POST" {
		var user models.User
		err := json.NewDecoder(r.Body).Decode(&user)
		if err != nil {
			http.Error(w, "Erreur lors de la lecture des données JSON", http.StatusBadRequest)
			return
		}

		// Vérifier si l'utilisateur existe dans la base de données
		db, err := sql.Open("sqlite3", "forum.db")
		if err != nil {
			http.Error(w, "Erreur de connexion à la base de données", http.StatusInternalServerError)
			return
		}
		defer db.Close()

		var dbPassword string
		err = db.QueryRow("SELECT mot_de_passe FROM utilisateur WHERE  username = ?", user.Username).Scan(&dbPassword)
		if err != nil {
			fmt.Println("Utilisateur non trouvé")
			http.Error(w, "Utilisateur non trouvé", http.StatusUnauthorized)
			return
		}
		fmt.Println("dbPassword", dbPassword)
		// Comparer les mots de passe
		// Comparer le mot de passe fourni avec le hash stocké dans la base de données
		err = bcrypt.CompareHashAndPassword([]byte(dbPassword), []byte(user.Password))
		if err != nil {
			fmt.Println("Mot de passe incorrect")
			http.Error(w, "Mot de passe incorrect", http.StatusUnauthorized)
			return
		}
		var userID int
		// Créer une session pour l'utilisateur
		err = db.QueryRow("SELECT id FROM utilisateur WHERE  username = ?", user.Username).Scan(&userID)
		if err != nil {
			fmt.Println("Utilisateur non trouvé session")
			http.Error(w, "Utilisateur non trouvé session", http.StatusUnauthorized)
			return
		}

		fmt.Println(userID)
		session, err := store.Get(r, "digiforum")
		if err != nil {
			http.Error(w, "Erreur de session", http.StatusInternalServerError)
			return
		}
		session.Values["user"] = userID
		// Définir d'autres valeurs de session si nécessaire
		// Définir l'expiration de la session
		session.Options = &sessions.Options{
			MaxAge:   1800, // durée de vie de la session en secondes (ici,30 min)
			HttpOnly: true,
			Secure:   true,
		}

		// Enregistrer la session
		err = session.Save(r, w)
		if err != nil {
			http.Error(w, "Erreur de session", http.StatusInternalServerError)
			return
		}
		// Authentification réussie
		// Vous pouvez renvoyer une réponse avec un code de statut 200 pour indiquer une connexion réussie
		// ou renvoyer des données supplémentaires sur l'utilisateur connecté si nécessaire
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("Connexion réussie"))

	}
}

// deconnexion
func DeconnexionHandler(w http.ResponseWriter, r *http.Request) {
	// Récupérer la session de l'utilisateur
	session, err := store.Get(r, "digiforum")
	if err != nil {
		http.Error(w, "Erreur de session", http.StatusInternalServerError)
		return
	}

	// Supprimer le cookie de session en fixant la durée de vie à une valeur négative
	session.Options.MaxAge = -1
	err = session.Save(r, w)
	if err != nil {
		http.Error(w, "Erreur de session", http.StatusInternalServerError)
		return
	}

	// Rediriger l'utilisateur vers la page d'accueil ou une autre page
	http.Redirect(w, r, "/form", http.StatusFound)
}

func GetAllCategrie(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		categories, err := models.FindAllCategorie()
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println("categories", categories)

		tmpl := template.Must(template.ParseFiles("views/acceuil.html"))
		errs := tmpl.Execute(w, categories)

		if errs != nil {
			http.Error(w, "Erreur lors de la conversion de la réponse en JSON", http.StatusInternalServerError)
			return
		}
	}
}

// fonction pour verifier si un utilisateur exist dans la base de donnée
func userExists(value string, column string) bool {
	// Ouvrir la connexion à la base de données
	db, err := sql.Open("sqlite3", "forum.db")
	if err != nil {
		// Gérer l'erreur de connexion à la base de données
		return true // Supposons que l'utilisateur existe pour éviter de créer une nouvelle inscription
	}
	defer db.Close()

	// Préparer la requête SQL pour vérifier si la valeur existe déjà
	query := "SELECT COUNT(*) FROM utilisateur WHERE " + column + " = ?"
	var count int
	err = db.QueryRow(query, value).Scan(&count)
	if err != nil {
		// Gérer l'erreur de requête SQL
		return true // Supposons que l'utilisateur existe pour éviter de créer une nouvelle inscription
	}

	return count > 0 // Si count > 0, cela signifie que l'utilisateur existe déjà, sinon non
}

// communication de base
func PublicationHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		session, _ := store.Get(r, "digiforum")
		if session.IsNew {
			http.Error(w, "User not authenticated", http.StatusUnauthorized)
			return
		}

		// Récupérer l'utilisateur de la session
		username, ok := session.Values["user"].(int)
		if !ok {
			http.Error(w, "User not authenticated", http.StatusUnauthorized)
			return
		}

		var publication models.Post
		err := json.NewDecoder(r.Body).Decode(&publication)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		// Ajouter l'utilisateur à la publication
		publication.User = username

		// Enregistrer la publication (ici nous imprimons simplement pour l'exemple)
		fmt.Println("publication", publication)
		data := models.CreatePost(publication)
		if data == nil {
			w.WriteHeader(http.StatusOK)
			fmt.Fprintln(w, "Publication successful")
		} else {
			http.Error(w, "Failed to create publication", http.StatusInternalServerError)
		}

	}
}

// verifie si l'utilisateur est authentifier
func CheckSession(w http.ResponseWriter, r *http.Request) {
	// Récupérer la session
	session, err := store.Get(r, "digiforum")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	// Créer une map pour la réponse JSON
	response := make(map[string]interface{})

	// Vérifier si le cookie de session existe
	if session.IsNew {
		// Cookie de session non trouvé
		w.WriteHeader(http.StatusUnauthorized)
		response["isLoggedIn"] = false
		response["message"] = "No active session"
	} else {
		// Cookie de session trouvé
		w.WriteHeader(http.StatusOK)
		response["isLoggedIn"] = true
		response["message"] = "Active session found"
		// Vous pouvez aussi accéder à des données de session ici
		if val, ok := session.Values["username"].(string); ok {
			response["username"] = val
		}
	}

	// Convertir la réponse en JSON et l'envoyer
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// recuperer tous les publications
func GetAllPublicationHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {

		data, err := models.GetAllPost()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		fmt.Println("data", data)
		tmpl := template.Must(template.ParseFiles("Templates/acceuil.html"))
		errs := tmpl.Execute(w, data)
		if errs != nil {
			http.Error(w, errs.Error(), http.StatusInternalServerError)
			return
		}
	}
}

// recuperer tous les commentaires
func CommentairesHandler(w http.ResponseWriter, r *http.Request) {
	//GET  pour recuperer les commentaires
	if r.Method == "GET" {
		//je recupere le id de la publications  passé en parametre
		idPublicationStr := r.URL.Query().Get("id")
		if idPublicationStr == "" {
			http.Error(w, "Missing 'id' query parameter", http.StatusBadRequest)
			return
		}
		// je convertis id de la publication (string)  en entier(int)
		idPublication, err := strconv.Atoi(idPublicationStr)
		if err != nil {
			http.Error(w, "Invalid 'id' query parameter", http.StatusBadRequest)
			return
		}
		//fmt.Println("idPublication", idPublication)
		//je recupere tout les donnee de la publication
		dataPost, err := models.GetOnePost(idPublication)
		if err != nil {
			log.Printf("Error fetching post: %v", err)
			http.Error(w, "Error fetching post", http.StatusInternalServerError)
			return
		}
		//fmt.Println("dataPost", dataPost)
		//je passe l'id de la publication a la fonction pour recuperer tout les commentaires liés a la publication
		dataCommentaires, err := models.GetAllComment(idPublication)
		if err != nil {
			log.Printf("Error fetching commentaire: %v", err)
			http.Error(w, "Error fetching commentaire", http.StatusInternalServerError)
			return
		}

		data := FormDataComment{
			//je passe la publication et les commentaires pour l'envoyer au front, jai creer une structure speciale pour
			Publication:  dataPost,
			Commentaires: dataCommentaires,
		}
		//fmt.Println("dataCommentaires", data.Publication)
		//fmt.Println("FormDataComment", data)
		tpl := template.Must(template.ParseFiles("views/commentaire.html"))
		//envoyer la data au template(front)
		if err := tpl.Execute(w, data); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}
	//POST pour creer un commentaire
	if r.Method == "POST" {
		session, _ := store.Get(r, "digiforum")
		if session.IsNew {
			http.Error(w, "User not authenticated", http.StatusUnauthorized)
			return
		}

		// Récupérer l'utilisateur connecté grâce à la session
		userid, ok := session.Values["user"].(int)
		if !ok {
			http.Error(w, "User not authenticated", http.StatusUnauthorized)
			return
		}

		// Récupérer les données envoyées depuis le front
		var commentaire models.Comment
		err := json.NewDecoder(r.Body).Decode(&commentaire)
		if err != nil {
			http.Error(w, "Failed to decode JSON: "+err.Error(), http.StatusBadRequest)
			return
		}
		commentaire.UserID = userid
		commentaire.CreatedAt = time.Now()

		// Enregistrer la publication (ici nous imprimons simplement pour l'exemple)

		data := models.CreateComment(commentaire) // Assuming this is your function to save the comment
		if data == nil {
			w.WriteHeader(http.StatusOK)
			fmt.Fprintln(w, "commentaire successful")
		} else {
			http.Error(w, "Failed to create commentaire", http.StatusInternalServerError)
		}
	}

}

// LikeDislikeCommentHandler gère les likes et dislikes des publications
func LikeDislikePostHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	session, _ := store.Get(r, "digiforum")
	if session.IsNew {
		http.Error(w, "User not authenticated", http.StatusUnauthorized)
		return
	}

	userid, ok := session.Values["user"].(int)
	if !ok {
		http.Error(w, "User not authenticated", http.StatusUnauthorized)
		return
	}

	var requestData struct {
		PostID   int    `json:"post_id"`
		LikeType string `json:"like_type"`
	}

	err := json.NewDecoder(r.Body).Decode(&requestData)
	if err != nil {
		fmt.Println(err.Error())
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	fmt.Println("----------------welcome-------------------", requestData)
	err = models.HandlePostLikeDislike(requestData.PostID, userid, requestData.LikeType)
	if err != nil {
		http.Error(w, "Failed to process like/dislike", http.StatusInternalServerError)
		return
	}

	response := struct {
		LikeCount    int `json:"likeCount"`
		DislikeCount int `json:"dislikeCount"`
	}{
		LikeCount:    models.GetPostLikesCount(requestData.PostID, "liked"),
		DislikeCount: models.GetPostLikesCount(requestData.PostID, "dislike"),
	}
	fmt.Println("response", response)
	w.Header().Set("Content-Type", "application/json")

	json.NewEncoder(w).Encode(response)
}

// LikeDislikeCommentHandler gère les likes et dislikes des commentaires
func LikeDislikeCommentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	session, _ := store.Get(r, "digiforum")
	if session.IsNew {
		http.Error(w, "User not authenticated", http.StatusUnauthorized)
		return
	}

	userid, ok := session.Values["user"].(int)
	if !ok {
		http.Error(w, "User not authenticated", http.StatusUnauthorized)
		return
	}

	var requestData struct {
		CommentID int    `json:"comment_id"`
		LikeType  string `json:"like_type"`
	}

	err := json.NewDecoder(r.Body).Decode(&requestData)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	fmt.Println("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", requestData.CommentID, userid, requestData.LikeType)
	err = models.HandleCommentLikeDislike(requestData.CommentID, userid, requestData.LikeType)
	if err != nil {
		http.Error(w, "Failed to process like/dislike", http.StatusInternalServerError)
		return
	}

	response := struct {
		LikeCount    int `json:"likeCount"`
		DislikeCount int `json:"dislikeCount"`
	}{
		LikeCount:    models.GetCommentLikesCount(requestData.CommentID, "liked"),
		DislikeCount: models.GetCommentLikesCount(requestData.CommentID, "dislike"),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
