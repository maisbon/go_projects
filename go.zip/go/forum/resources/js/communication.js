document.addEventListener('DOMContentLoaded', function () {
    // Effectuer une requête pour vérifier l'état de la session
    fetch('/checkSession')
        .then(response => response.json())
        .then(data => {
            if (data.isLoggedIn) {
                // Utilisateur connecté
                document.getElementById('loginButton').style.display = 'none';
                document.getElementById('logoutButton').style.display = 'inline';
            } else {
                // Utilisateur non connecté
                document.getElementById('loginButton').style.display = 'inline';
                document.getElementById('logoutButton').style.display = 'none';
            }
        })
        .catch(error => console.error('Error checking session:', error));


});

document.querySelector('.poster-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Empêche le formulaire de se soumettre normalement
    var title = document.querySelector('input[name="title"]').value;
    var threadPost = document.querySelector('textarea[name="content"]').value;
    var selectedValue = document.querySelector('select[name="categorie"]').value; // Récupérer la valeur de l'input select
    // Ajouter un écouteur d'événement pour le changement de valeur
    // var customFile = document.querySelector('input[name="customFile"]').files; // Pour les fichiers
    var formData = {
        title: title,
        content: threadPost,
        categorie: parseInt(selectedValue, 10)
    };

    if (!threadPost.trim()) {
        alert("Le champ message ne peut pas être vide.");
        return; // Arrêter la soumission du formulaire
    }

    fetch("/publier", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
    }).then(response => {
        if (!response.ok) {
            throw new Error("Erreur de publication");
        }
        // Ne pas essayer de parser la réponse comme JSON, car elle n'est pas JSON
        return response.text(); // Récupérer le texte de la réponse
    }).then(data => {
        // Afficher la réponse du serveur
        console.log("Réponse du serveur:", data);
        // Fermer le modal
        $('#threadModal').modal('hide');
        // Afficher une notification de succès
        var successNotification = document.getElementById('successNotification');
        successNotification.style.display = 'block';
        successNotification.textContent = "Publication réussie!";
        setTimeout(function () {
            successNotification.style.display = 'none';
        }, 3000); // Masquer la notification après 3 secondes
        location.reload();
    }).catch(error => {
        console.error("Erreur:", error.message);
    });
});

document.getElementById('threadButton').addEventListener('click', function () {
    fetch('/checkSession')
        .then(response => response.json())
        .then(data => {
            if (data.isLoggedIn) {
                // Utilisateur connecté
                $('#threadModal').modal('show');
            } else {
                // Utilisateur non connecté
                $('#authModal').modal('show');
            }
        }).catch(error => console.error('Error checking session:', error));
});

document.querySelectorAll('.like-button, .dislike-button').forEach(button => {
    button.addEventListener('click', function () {
        const targetId = parseInt(this.getAttribute('data-id'), 10); // Convert to integer
        const targetType = this.getAttribute('data-type');
        const action = this.getAttribute('data-action');
        console.log("targetType", targetType)
        console.log("action", action)
        fetch(`/like-dislike-${targetType}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ [`${targetType}_id`]: targetId, like_type: action })
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to like/dislike');
                }
                return response.json(); // Assuming server returns JSON with like and dislike counts
            })
            .then(data => {
                // Update UI with like and dislike counts
                if (action === 'liked') {
                    const likeCountElement = this.querySelector('.like-count');
                    if (likeCountElement) {
                        likeCountElement.textContent = data.likeCount; // Update like count
                        location.reload();
                    }
                } else if (action === 'dislike') {
                    const dislikeCountElement = this.querySelector('.dislike-count');
                    if (dislikeCountElement) {
                        dislikeCountElement.textContent = data.dislikeCount; // Update dislike count
                        location.reload();
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
});


