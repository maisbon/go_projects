

document.addEventListener('DOMContentLoaded', function () {
    // Effectuer une requête pour vérifier l'état de la session
    fetch('/checkSession')
        .then(response => response.json())
        .then(data => {
            if (data.isLoggedIn) {
                // Utilisateur connecté
                document.getElementById('loginButton').style.display = 'none';
                document.getElementById('logoutButton').style.display = 'inline';
            } else {
                // Utilisateur non connecté
                document.getElementById('loginButton').style.display = 'inline';
                document.getElementById('logoutButton').style.display = 'none';
            }
        })
        .catch(error => console.error('Error checking session:', error));


});
document.getElementById('threadButton').addEventListener('click', function () {
    fetch('/checkSession')
        .then(response => response.json())
        .then(data => {
            if (data.isLoggedIn) {
                // Utilisateur connecté
                $('#threadModal').modal('show');
            } else {
                // Utilisateur non connecté
                $('#authModal').modal('show');
            }
        }).catch(error => console.error('Error checking session:', error));
});

document.querySelector('.poster-form-comment').addEventListener('submit', function (event) {
    event.preventDefault(); // Empêche le formulaire de se soumettre normalement
    var threadPost = document.querySelector('textarea[name="content"]').value;
    var idPost = document.querySelector('input[name="idpost"]').value;
    var formData = {
        content: threadPost,
        post_id: parseInt(idPost, 10), // Convertir en entier
        user_id: 0 // Ce champ sera remplacé par l'ID utilisateur sur le serveur
    };

    // Vérifier si le champ threadPost est vide
    if (!threadPost.trim()) {
        alert("Le champ commentaire ne peut pas être vide.");
        return; // Arrêter la soumission du formulaire
    }


    console.log(formData);
    fetch("/commenter", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
    }).then(response => {
        if (!response.ok) {
            throw new Error("Erreur de publication");
        }
        return response.text(); // Récupérer le texte de la réponse
    }).then(data => {
        console.log("Réponse du serveur:", data);
        // Fermer le modal
        $('#threadModal').modal('hide');
        // Afficher une notification de succès
        var successNotification = document.getElementById('successNotification');
        successNotification.style.display = 'block';
        successNotification.textContent = "commentaire réussie!";
        setTimeout(function () {
            successNotification.style.display = 'none';
        }, 3000); // Masquer la notification après 3 secondes
        location.reload();
    }).catch(error => {
        console.error("Erreur:", error.message);
    });
});

document.querySelectorAll('.like-button, .dislike-button').forEach(button => {
    button.addEventListener('click', function () {
        const targetId = parseInt(this.getAttribute('data-id'), 10); // Convert to integer
        const targetType = this.getAttribute('data-type');
        const action = this.getAttribute('data-action');
        console.log("targetType", targetType)
        console.log("action", action)
        fetch(`/like-dislike-${targetType}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ [`${targetType}_id`]: targetId, like_type: action })
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to like/dislike');
                }
                return response.json(); // Assuming server returns JSON with like and dislike counts
            })
            .then(data => {
                // Update UI with like and dislike counts
                if (action === 'liked') {
                    const likeCountElement = this.querySelector('.like-count');
                    if (likeCountElement) {
                        likeCountElement.textContent = data.likeCount; // Update like count
                        location.reload();
                    }
                } else if (action === 'dislike') {
                    const dislikeCountElement = this.querySelector('.dislike-count');
                    if (dislikeCountElement) {
                        dislikeCountElement.textContent = data.dislikeCount; // Update dislike count
                        location.reload();
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
});

