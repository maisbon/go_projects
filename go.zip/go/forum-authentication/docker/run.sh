docker container run -p 5000:5000 --name forum forum
echo "Docker started, go to:"
echo "http://localhost:5000"