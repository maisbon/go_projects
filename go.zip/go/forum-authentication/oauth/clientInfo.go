package oauth

const (
	GoogleClientID     = "604588800983-r1jfronei22jicn61n03rhrt5o118i97.apps.googleusercontent.com"
	GoogleClientSecret = "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"
	GoogleRedirectURI  = "http://localhost:5000/google/callback"
	GithubClientID     = ""
	GithubClientSecret = ""
	GithubRedirectURI  = "http://localhost:5000/oauth/github"
)
