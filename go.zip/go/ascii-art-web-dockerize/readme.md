
Projet Docker avec Serveur Web en Go : 



Ce projet consiste à créer un serveur web en utilisant le langage Go et à le conteneuriser avec Docker. Le but est de comprendre les bases du web, le fonctionnement d'un serveur web, ainsi que les principes de Docker et son utilisation pour conteneuriser des applications.




construire l'image :
 sudo docker image build -f Dockerfile -t <name_of_the_image> . 


commande pour voir l'image :

  sudo docker images


commande pour créer le conteneur : 
 sudo docker container run -p <port_you_what_to_run> --detach --name <name_of_the_container> <name_of_the_image>


  Port : 4000 
  http://localhost:4000

commande pour voir tout les containers :

 sudo docker ps -a 

commande pour entrée dans le conteneur : 
 sudo docker exec -it <container_name> /bin/bash


commande pour lister tout les fichiers présent : 
ls -l