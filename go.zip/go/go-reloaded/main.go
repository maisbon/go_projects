
package main
import (
    "os"
    "strconv"
    "strings"
    "unicode/utf8"
)
var arr []string // étant donné le document txt découpé en tableau par des espaces
func numConv(index, base int) { // convertit de hexadécimal/binaire en décimal
    var temparr []string
    decimal, err := strconv.ParseInt(arr[index-1], base, 64)
    if err == nil {
        arr[index-1] = strconv.Itoa(int(decimal))
        if len(arr)-1 == index {
            temparr = append(arr[:0], arr[:index]...)
        } else {
            temparr = append(arr[:index], arr[index+1:]...)
        }
        arr = temparr
    }
}
func Convert(index int, fn func(string) string) { // convertit en capital, à la hausse ou à la baisse
    if len(arr)-1 == index {
        arr[index-1] = fn(arr[index-1])
        temparr := append(arr[:index], arr[index+1:]...)
        arr = temparr
        return
    }
    num, err := strconv.Atoi(string(arr[index+1][:len(arr[index+1])-1]))
    if err == nil {
        for i := index - 1; i >= index-int(num); i-- {
            arr[i] = fn(arr[i])
        }
        temparr := append(arr[:index], arr[index+2:]...)
        arr = temparr
    } else {
        arr[index-1] = fn(arr[index-1])
        temparr := append(arr[:index], arr[index+1:]...)
        arr = temparr
    }
}
func RemoveIndex(index, count int) {
    temparr := append(arr[:index], arr[index+count:]...)
    arr = temparr
}
func main() {
    var check bool
    content, err := os.ReadFile(os.Args[1]) // lit le document texte, donné en arguments
    if err != nil {                         // si nous avons une erreur, alors arrêtons tout
        return
    }
    arr = strings.Fields(string(content)) // le divise par espace dans un tableau global
    for i := 0; i < len(arr); i++ { // s'occupe des cas de parenthèses
        if len(arr[i]) > 3 {
            switch arr[i][:4] {
            case "(bin":
                numConv(i, 2)
                i--
            case "(hex":
                numConv(i, 16)
                i--
            case "(cap":
                Convert(i, strings.Title)
                i--
            case "(up,":
                Convert(i, strings.ToUpper)
                i--
            case "(up)":
                Convert(i, strings.ToUpper)
                i--
            case "(low":
                Convert(i, strings.ToLower)
                i--
            }
        }
        if len(arr[i]) == 0 { // si nous avons un tableau vide alors nous le supprimons
            temparr := append(arr[:i], arr[i+1:]...)
            arr = temparr
            i--
            continue
        }
        switch arr[i][0] { // traite des ponctuations
        case '.', ',', '!', '?', ':', ';':
            arr[i-1] = arr[i-1] + string(arr[i][0])
            arr[i] = arr[i][1:]
            i--
            continue
        }
        switch arr[i] { // traite de un et un
        case "a", "A":
            if strings.ContainsAny(string(arr[i+1][0]), "aeiouh") {
                arr[i] += "n"
            }
        case "an", "An":
            if !strings.ContainsAny(string(arr[i+1][0]), "aeiouh") {
                arr[i] = string(arr[i][0])
            }
        }
        lastrune, size1 := utf8.DecodeLastRune([]byte(arr[i])) // obtient la première et la dernière rune, c'est fait avec utf8, parce que...
        firstrune, size2 := utf8.DecodeRuneInString(arr[i])    // ... le ' est dans la table Unicode étendue
        if size1 < 1 && size2 < 1 {
            continue
        }
        if check && (string(firstrune) == "'" || firstrune == 8216) { // vérifie ' et '
            check = false
            arr[i-1] = arr[i-1] + string(firstrune) // mot 'mot
            arr[i] = arr[i][size2:]
            if len(arr[i]) == 0 {
                temparr := append(arr[:i], arr[i+1:]...)
                arr = temparr
                i--
            }
        } else if string(lastrune) == "'" || lastrune == 8216 { //mot ' mot
            check = true
            if string(lastrune) == "'" {
                arr[i+1] = string(lastrune) + arr[i+1]
                arr[i] = arr[i][:len(arr[i])-1]
            } else {
                arr[i+1] = arr[i] + arr[i+1]
                arr[i] = ""
            }
            if len(arr[i]) == 0 {
                temparr := append(arr[:i], arr[i+1:]...)
                arr = temparr
            }
        } else if string(firstrune) == "'" || firstrune == 8216 {
            check = true
        } else if string(lastrune) == "'" || lastrune == 8216 {
            check = false
        }
    }
    os.WriteFile("result.txt", []byte(strings.Join(arr, " ")), 0644)
} 
