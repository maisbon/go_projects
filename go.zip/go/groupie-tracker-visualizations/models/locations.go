package models

// LocationData représente la structure des données de l'API Location
type LocationData struct {
	Index []Location `json:"index"`
}

// Location représente une entrée dans l'API Location
type Location struct {
	ID            int                 `json:"id"`
	Locations     []string            `json:"locations"`
	Dates         string              `json:"dates"`
	Dateconcert   []string            `json:"dateconcert"`
	DatesRelation map[string][]string `json:"daterelation"`
}
