# groupie-tracker-visualizations
Groupie-tracker-visualizations est un projet en go de visualisation de données sur les groupes de musique.

## Utilisation
1 - Assurez-vous d'avoir Go installé sur votre système.
2 - cloner le repertoire

3 - Exécutez l'application :
go run .

4- Ouvrez votre navigateur web et accédez à http://localhost:8080 pour accéder au site.

## Fonctionnalités

1- Chargement des données depuis une API : Le programme charge les données des artistes, des lieux et des 
dates depuis l'API Groupie Tracker.

2- Affichage des artistes : Affiche la liste des artistes sur la page d'accueil.

## Structure du Code

Le code est organisé comme suit :

controllers/ : Contient les fonctions de gestion des routes et des requêtes HTTP.

models/ : Contient les modèles de données utilisés par l'application.

templates/ : Contient les fichiers HTML utilisés pour l'affichage des pages.

## Auteurs

Ce projet a été développé par 

1- malarissa

2- kstephanie

3- kmakissi





