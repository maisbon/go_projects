package main

import (
	"fmt"
	"groupie-tracker-visualizations/controllers"
	"net/http"
	"os"
)

const port = ":8080"

func main() {
	http.HandleFunc("/", controllers.HandleAccueil)
	http.HandleFunc("/singers", controllers.HandleSingers)
	http.HandleFunc("/artists/", controllers.HandleDetails)
	http.HandleFunc("/404", controllers.HandleError404)
	// Gestion des fichiers statiques
	fs := http.FileServer(http.Dir("static"))
	http.Handle("/static/", http.StripPrefix("/static/", fs))

	//démarre le serveur web en écoutant sur le port
	fmt.Printf("Server started on http://localhost%v\n", port)
	if err := http.ListenAndServe(port, nil); err != nil {
		fmt.Printf("Error starting the server: %v\n", err)
		os.Exit(1)
	}
}
