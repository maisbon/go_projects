package controllers

import (
	"encoding/json"
	"fmt"
	"groupie-tracker-visualizations/models"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"strings"
)

func HandleAccueil(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" && r.URL.Path != "/artists/" && r.URL.Path != "/singers" {
		http.Redirect(w, r, "/404", http.StatusSeeOther)
		return
	}
	resp, err := template.ParseFiles("templates/accueil.html")
	if err != nil {
		log.Printf("Erreur de lecture du template: %v", err)
		codeErreur(w, r, 500, "Error Parsing File accueil.html")
	}
	// telecharger les artists sur la page d'accueil
	resp.Execute(w, nil)
}

// Gère l'affichage des artists
func HandleSingers(w http.ResponseWriter, r *http.Request) {

	artists, err := LoadArtists()
	if err != nil {
		log.Printf("Erreur de chargement: %v", err)
		codeErreur(w, r, 500, "Error loading artist data")
		return
	}

	resp, err := template.ParseFiles("templates/singers.html")
	if err != nil {
		log.Printf("Erreur de lecture du template: %v", err)
		codeErreur(w, r, 500, "Error Parsing File singers.html")
	}
	// telecharger les artists sur la page d'accueil
	resp.Execute(w, artists)
}

// HandleDetails gère l'affichage des détails d'un artiste en particulier
func HandleDetails(w http.ResponseWriter, r *http.Request) {
	// Récupère l'ID de l'URL
	parts := strings.Split(r.URL.Path, "/artists/")
	id := parts[len(parts)-1]

	// Converti l'ID en un entier
	artistID, err := strconv.Atoi(id)
	if err != nil {
		codeErreur(w, r, 400, "Invalid artist ID")
		return
	}

	// Charge les données des artistes
	artists, err := LoadArtists()
	if err != nil {
		log.Printf("Erreur de chargement: %v", err)
		codeErreur(w, r, 500, "Error loading artist data")
		return
	}

	// Trouve l'artiste avec l'ID correspondant
	var selectedArtist models.Artist
	for _, artist := range artists {
		if artist.ID == artistID {
			selectedArtist = artist
			break
		}
	}

	// Charge les données des lieux
	locations, err := LoadLocations()
	if err != nil {
		log.Printf("Erreur de chargement: %v", err)
		codeErreur(w, r, 500, "Error loading location data")
		return
	}
	// Trouve le lieu avec l'ID correspondant
	var selectedLocation models.Location
	for _, location := range locations {
		if location.ID == artistID {
			selectedLocation = location
			resp, error := http.Get(selectedLocation.Dates)
			if error != nil {
				log.Fatalln(error)
			}

			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				log.Fatalln(err)
			}
			//Convertir body (donnée dates en json)
			var dates models.Date
			err = json.Unmarshal(body, &dates)
			if err != nil {
				log.Fatalln(err)
			}
			// aller rechercher la relation de location
			apiUrl := fmt.Sprintf("https://groupietrackers.herokuapp.com/api/relation/%d", artistID)
			resRelation, error := http.Get(apiUrl)
			if error != nil {
				log.Fatalln(error)
			}

			bodyRelation, err := ioutil.ReadAll(resRelation.Body)
			if err != nil {
				log.Fatalln(err)
			}
			//Convertir body (donnée relation en json)
			var relation models.Relation
			err = json.Unmarshal(bodyRelation, &relation)
			if err != nil {
				log.Fatalln(err)
			}
			selectedLocation.Dateconcert = dates.Dates
			selectedLocation.DatesRelation = relation.DatesLocations
			break
		}
	}

	// Vérifie si le lieu existe
	if selectedLocation.ID == 0 {
		codeErreur(w, r, 404, "Location Not Found")
		return
	}

	// Charge le template HTML
	tmpl, err := template.ParseFiles("templates/details.html")
	if err != nil {
		codeErreur(w, r, 500, "Erreur Parsing File details.html")
		return
	}

	// Affiche les détails de l'artiste sur la page
	data := struct {
		Artist   models.Artist
		Location models.Location
	}{
		Artist:   selectedArtist,
		Location: selectedLocation,
	}
	// Imprimer les données envoyées au template dans la console du serveur
	//fmt.Println("Données envoyées au template :", data)

	// Charge la page
	if err := tmpl.Execute(w, data); err != nil {
		codeErreur(w, r, 500, "Error executing template")
		return
	}
}
func HandleError404(w http.ResponseWriter, r *http.Request) {
	// Charge le template HTML
	w.WriteHeader(http.StatusNotFound)

	errtemplates := template.Must(template.ParseFiles("templates/error404.html"))
	err := errtemplates.ExecuteTemplate(w, "error404.html", nil)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError) //erreur 500
		return
	}
}
