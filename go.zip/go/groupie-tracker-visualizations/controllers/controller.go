package controllers

import (
	"encoding/json"
	"fmt"
	"groupie-tracker-visualizations/models"
	"io/ioutil"
	"log"
	"net/http"
)

// loadApi charge les données des différentes API
func loadApi(v interface{}, endpoint string) error {
	// Tableau contenant le dernier élément de l'URL de chaque API
	tab := [4]string{"artists", "locations", "dates", "relation"}

	endpointIsValid := false

	// Vérification de la similarité du paramètre et des éléments du tableau
	for i := 0; i < len(tab); i++ {
		if endpoint == tab[i] {
			endpointIsValid = true
			break
		}
	}

	// Si le paramètres 'endpoint' ne correspond pas à un élément du tableau, alos on gère l'erreur
	if !endpointIsValid {
		return fmt.Errorf("Erreur: url invalide")
	}

	// Récupération de l'API voulu
	response, err := http.Get("https://groupietrackers.herokuapp.com/api/" + endpoint)

	if err != nil {
		log.Printf("Erreur de récupération de %s: %v\n", endpoint, err)
		return fmt.Errorf("Erreur de récupération de %s: %w", endpoint, err)
	}

	// Lecture de l'API
	responseData, err := ioutil.ReadAll(response.Body)

	if err != nil {
		log.Printf("Erreur de lecture de %s: %v\n", endpoint, err)
		return fmt.Errorf("Erreur de lecture de %s: %w", endpoint, err)
	}
	//convertir notre api en structure de données go
	err = json.Unmarshal(responseData, &v)
	if err != nil {
		log.Printf("Erreur du decodage JSON de %s: %v\n", endpoint, err)
		return fmt.Errorf("Erreur du decodage JSON de %s: %w", endpoint, err)
	}
	return nil
}

// LoadArtists charge les données des artistes depuis l'API correspondante
func LoadArtists() ([]models.Artist, error) {
	var dataArtists []models.Artist
	err := loadApi(&dataArtists, "artists")
	if err != nil {
		return nil, err
	}
	return dataArtists, nil
}

// LoadLocations charge les données des lieux depuis l'API correspondante
func LoadLocations() ([]models.Location, error) {
	var locationData models.LocationData

	// Appel à la fonction loadApi pour récupérer les données de localisation
	err := loadApi(&locationData, "locations")
	if err != nil {
		return nil, err
	}

	return locationData.Index, nil
}

// LoadDates charge les données des dates depuis l'API correspondante
func LoadDates() ([]models.Date, error) {
	var dataDates []models.Date
	err := loadApi(&dataDates, "dates")
	if err != nil {
		return nil, err
	}
	return dataDates, nil
}

// LoadRelations charge les données des relations depuis l'API correspondante
func LoadRelations() ([]models.Relation, error) {
	var dataRelations []models.Relation
	err := loadApi(&dataRelations, "relation")
	if err != nil {
		return nil, err
	}
	return dataRelations, nil
}

func codeErreur(w http.ResponseWriter, r *http.Request, status int, message string) {

	// Mise en place de condition pour les différents types d'erreurs
	if status == 404 {
		http.Error(w, "404 not found", http.StatusNotFound) // Mise en place d'un message qui sera afficher lors de l'erreur
	}
	if status == 400 {
		http.Error(w, "400 Bad request", http.StatusBadRequest)
	}
	if status == 500 {
		http.Error(w, "500 Internal server error", http.StatusInternalServerError)
	}

}
