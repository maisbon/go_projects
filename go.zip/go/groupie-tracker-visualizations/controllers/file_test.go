package controllers

import (
	"testing"
)

func TestLoadApi_Error(t *testing.T) {
	// Appel de la fonction loadApi avec une URL invalide
	var testData map[string]interface{}
	err := loadApi(&testData, "invalid-url")
	if err == nil {
		t.Error("loadApi() n'a pas retourné d'erreur pour une URL invalide")
	}
	expectedErrorMsg := "Erreur: url invalide"
	if err.Error() != expectedErrorMsg {
		t.Errorf("L'erreur retournée ne correspond pas à l'erreur attendue. Attendu: %s, Reçu: %s", expectedErrorMsg, err.Error())
	}
	if testData != nil {
		t.Error("Les données retournées devraient être nulles en cas d'erreur")
	}
}

/*
func TestHandleAccueil(t *testing.T) {
	req, err := http.NewRequest("GET", "/", nil)
	if err != nil {
		t.Fatalf("Erreur lors de la création de la requête: %v", err)
	}
	w := httptest.NewRecorder()
	HandleAccueil(w, req)
	if w.Code != http.StatusOK {
		t.Errorf("Le code de statut de la réponse n'est pas OK. Attendu: %d, Reçu: %d", http.StatusOK, w.Code)
	}
}

func TestHandleSingers(t *testing.T) {
	req, err := http.NewRequest("GET", "/singers", nil)
	if err != nil {
		t.Fatalf("Erreur lors de la création de la requête: %v", err)
	}
	w := httptest.NewRecorder()
	HandleSingers(w, req)
	if w.Code != http.StatusOK {
		t.Errorf("Le code de statut de la réponse n'est pas OK. Attendu: %d, Reçu: %d", http.StatusOK, w.Code)
	}
}

func TestHandleDetails(t *testing.T) {
	req, err := http.NewRequest("GET", "/artists/1", nil)
	if err != nil {
		t.Fatalf("Erreur lors de la création de la requête: %v", err)
	}
	w := httptest.NewRecorder()
	HandleDetails(w, req)
	if w.Code != http.StatusOK {
		t.Errorf("Le code de statut de la réponse n'est pas OK. Attendu: %d, Reçu: %d", http.StatusOK, w.Code)
	}
}

func TestHandleError404(t *testing.T) {
	req, err := http.NewRequest("GET", "/404", nil)
	if err != nil {
		t.Fatalf("Erreur lors de la création de la requête: %v", err)
	}
	w := httptest.NewRecorder()
	HandleError404(w, req)
	if w.Code != http.StatusNotFound {
		t.Errorf("Le code de statut de la réponse n'est pas NotFound. Attendu: %d, Reçu: %d", http.StatusNotFound, w.Code)
	}
}
*/
